import urllib.request
from urllib.parse import urlparse
import re
import os
from datetime import datetime, timedelta, timezone
import random
import opencc
import socket
import time

# 创建输出目录
output_dir = "output"
os.makedirs(output_dir, exist_ok=True)

# 繁体中文转简体中文
def traditional_to_simplified(text: str) -> str:
    converter = opencc.OpenCC('t2s')
    simplified_text = converter.convert(text)
    return simplified_text

# 记录脚本开始执行时间
timestart = datetime.now()

# 读取文本文件到数组
def read_txt_to_array(file_name):
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            lines = [line.strip() for line in lines if line.strip()]
            return lines
    except FileNotFoundError:
        print(f"File '{file_name}' not found.")
        return []
    except Exception as e:
        print(f"An error occurred: {e}")
        return []

# 从黑名单文件中读取黑名单
def read_blacklist_from_txt(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    BlackList = [line.split(',')[1].strip() for line in lines if ',' in line]
    return BlackList

# 读取自动和手动黑名单并合并
blacklist_auto = read_blacklist_from_txt('scripts/livesource/blacklist/blacklist_auto.txt')
blacklist_manual = read_blacklist_from_txt('scripts/livesource/blacklist/blacklist_manual.txt')
combined_blacklist = set(blacklist_auto + blacklist_manual)

# 定义各种频道分类的存储列表
yangshi_lines = []      # 央视
weishi_lines = []       # 卫视
beijing_lines = []      # 北京
shanghai_lines = []     # 上海
tianjin_lines = []      # 天津
chongqing_lines = []    # 重庆
guangdong_lines = []    # 广东
jiangsu_lines = []      # 江苏
zhejiang_lines = []     # 浙江
shandong_lines = []     # 山东
henan_lines = []        # 河南
sichuan_lines = []      # 四川
hebei_lines = []        # 河北
hunan_lines = []        # 湖南
hubei_lines = []        # 湖北
anhui_lines = []        # 安徽
fujian_lines = []       # 福建
shanxi1_lines = []      # 陕西
liaoning_lines = []     # 辽宁
jiangxi_lines = []      # 江西
heilongjiang_lines = [] # 黑龙江
jilin_lines = []        # 吉林
shanxi2_lines = []      # 山西
guangxi_lines = []      # 广西
yunnan_lines = []       # 云南
guizhou_lines = []      # 贵州
gansu_lines = []        # 甘肃
neimenggu_lines = []    # 内蒙古
xinjiang_lines = []     # 新疆
hainan_lines = []       # 海南
ningxia_lines = []      # 宁夏
qinghai_lines = []      # 青海
xizang_lines = []       # 西藏

news_lines = []         # 新闻
shuzi_lines = []        # 数字
dianying_lines = []     # 电影
jieshuo_lines = []      # 解说
zongyi_lines = []       # 综艺
huya_lines = []         # 虎牙
douyu_lines = []        # 斗鱼
xianggang_lines = []    # 香港
aomen_lines = []        # 澳门
china_lines = []        # 中国
guoji_lines = []        # 国际
gangaotai_lines = []    # 港澳台
dianshiju_lines = []    # 电视剧
radio_lines = []        # 收音机
donghuapian_lines = []  # 动画片
jilupian_lines = []     # 纪录片
tiyu_lines = []         # 体育
tiyusaishi_lines = []   # 体育赛事
youxi_lines = []        # 游戏
xiqu_lines = []         # 戏曲
yinyue_lines = []       # 音乐
chunwan_lines = []      # 春晚
zhibozhongguo_lines = [] # 直播中国
other_lines = []        # 其他
other_lines_url = []    # 其他频道URL

# 处理频道名称字符串
def process_name_string(input_str):
    parts = input_str.split(',')
    processed_parts = []
    for part in parts:
        processed_part = process_part(part)
        processed_parts.append(processed_part)
    result_str = ','.join(processed_parts)
    return result_str

# 处理单个频道名称部分
def process_part(part_str):
    if "CCTV" in part_str and "://" not in part_str:
        part_str = part_str.replace("IPV6", "")
        part_str = part_str.replace("PLUS", "+")
        part_str = part_str.replace("1080", "")
        filtered_str = ''.join(char for char in part_str if char.isdigit() or char == 'K' or char == '+')
        if not filtered_str.strip():
            filtered_str = part_str.replace("CCTV", "")
        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2:
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)
        return "CCTV" + filtered_str
    elif "卫视" in part_str:
        pattern = r'卫视「.*」'
        result_str = re.sub(pattern, '卫视', part_str)
        return result_str
    return part_str

# 获取URL文件扩展名
def get_url_file_extension(url):
    parsed_url = urlparse(url)
    path = parsed_url.path
    extension = os.path.splitext(path)[1]
    return extension

# 将M3U格式转换为TXT格式
def convert_m3u_to_txt(m3u_content):
    lines = m3u_content.split('\n')
    txt_lines = []
    channel_name = ""
    for line in lines:
        if line.startswith("#EXTM3U"):
            continue
        if line.startswith("#EXTINF"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith("http") or line.startswith("rtmp") or line.startswith("p3p"):
            txt_lines.append(f"{channel_name},{line.strip()}")
        if "#genre#" not in line and "," in line and "://" in line:
            pattern = r'^[^,]+,[^\s]+://[^\s]+$'
            if bool(re.match(pattern, line)):
                txt_lines.append(line)
    return '\n'.join(txt_lines)

# 检查URL是否已存在
def check_url_existence(data_list, url):
    urls = [item.split(',')[1] for item in data_list]
    return url not in urls

# 清理URL
def clean_url(url):
    last_dollar_index = url.rfind('$')
    if last_dollar_index != -1:
        return url[:last_dollar_index]
    return url

# 频道名称清理列表
removal_list = ["_电信", "电信", "高清", "频道", "（HD）", "-HD", "英陆", "_ITV", "(北美)", "(HK)", "AKtv", "「IPV4」", "「IPV6」", "[HD]", "[BD]", "[SD]", "[VGA]",
                "频陆", "备陆", "壹陆", "贰陆", "叁陆", "肆陆", "伍陆", "陆陆", "柒陆", "频晴", "频粤", "[超清]", "高清", "超清", "标清", "斯特",
                "粤陆", "国陆", "肆柒", "频英", "频特", "频国", "频壹", "频贰", "肆贰", "频测", "咪咕", "闽特", "高特", "频高", "频标", "汝阳",
                "4Gtv", "频效", "国标", "粤标", "频推", "频流", "粤高", "频限", "实时", "美推", "频美"]

# 清理频道名称
def clean_channel_name(channel_name, removal_list):
    for item in removal_list:
        channel_name = channel_name.replace(item, "")
    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]
    return channel_name

# 处理频道行
def process_channel_line(line):
    if "#genre#" not in line and "#EXTINF:" not in line and "," in line and "://" in line:
        channel_name = line.split(',')[0].strip()
        channel_name = clean_channel_name(channel_name, removal_list)
        channel_name = traditional_to_simplified(channel_name)
        channel_address = clean_url(line.split(',')[1].strip())
        line = channel_name + "," + channel_address
        
        if channel_address not in combined_blacklist:
            if "CCTV" in channel_name and channel_address not in [x.split(',')[1] for x in yangshi_lines]:
                yangshi_lines.append(process_name_string(line.strip()))
            elif "卫视" in channel_name and channel_address not in [x.split(',')[1] for x in weishi_lines]:
                weishi_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in beijing_dictionary) and channel_address not in [x.split(',')[1] for x in beijing_lines]:
                beijing_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in shanghai_dictionary) and channel_address not in [x.split(',')[1] for x in shanghai_lines]:
                shanghai_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in tianjin_dictionary) and channel_address not in [x.split(',')[1] for x in tianjin_lines]:
                tianjin_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in chongqing_dictionary) and channel_address not in [x.split(',')[1] for x in chongqing_lines]:
                chongqing_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in guangdong_dictionary) and channel_address not in [x.split(',')[1] for x in guangdong_lines]:
                guangdong_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in jiangsu_dictionary) and channel_address not in [x.split(',')[1] for x in jiangsu_lines]:
                jiangsu_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in zhejiang_dictionary) and channel_address not in [x.split(',')[1] for x in zhejiang_lines]:
                zhejiang_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in shandong_dictionary) and channel_address not in [x.split(',')[1] for x in shandong_lines]:
                shandong_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in henan_dictionary) and channel_address not in [x.split(',')[1] for x in henan_lines]:
                henan_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in sichuan_dictionary) and channel_address not in [x.split(',')[1] for x in sichuan_lines]:
                sichuan_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in hebei_dictionary) and channel_address not in [x.split(',')[1] for x in hebei_lines]:
                hebei_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in hunan_dictionary) and channel_address not in [x.split(',')[1] for x in hunan_lines]:
                hunan_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in hubei_dictionary) and channel_address not in [x.split(',')[1] for x in hubei_lines]:
                hubei_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in anhui_dictionary) and channel_address not in [x.split(',')[1] for x in anhui_lines]:
                anhui_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in fujian_dictionary) and channel_address not in [x.split(',')[1] for x in fujian_lines]:
                fujian_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in shanxi1_dictionary) and channel_address not in [x.split(',')[1] for x in shanxi1_lines]:
                shanxi1_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in liaoning_dictionary) and channel_address not in [x.split(',')[1] for x in liaoning_lines]:
                liaoning_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in jiangxi_dictionary) and channel_address not in [x.split(',')[1] for x in jiangxi_lines]:
                jiangxi_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in heilongjiang_dictionary) and channel_address not in [x.split(',')[1] for x in heilongjiang_lines]:
                heilongjiang_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in jilin_dictionary) and channel_address not in [x.split(',')[1] for x in jilin_lines]:
                jilin_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in shanxi2_dictionary) and channel_address not in [x.split(',')[1] for x in shanxi2_lines]:
                shanxi2_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in guangxi_dictionary) and channel_address not in [x.split(',')[1] for x in guangxi_lines]:
                guangxi_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in yunnan_dictionary) and channel_address not in [x.split(',')[1] for x in yunnan_lines]:
                yunnan_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in guizhou_dictionary) and channel_address not in [x.split(',')[1] for x in guizhou_lines]:
                guizhou_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in gansu_dictionary) and channel_address not in [x.split(',')[1] for x in gansu_lines]:
                gansu_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in neimenggu_dictionary) and channel_address not in [x.split(',')[1] for x in neimenggu_lines]:
                neimenggu_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in xinjiang_dictionary) and channel_address not in [x.split(',')[1] for x in xinjiang_lines]:
                xinjiang_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in hainan_dictionary) and channel_address not in [x.split(',')[1] for x in hainan_lines]:
                hainan_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in ningxia_dictionary) and channel_address not in [x.split(',')[1] for x in ningxia_lines]:
                ningxia_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in qinghai_dictionary) and channel_address not in [x.split(',')[1] for x in qinghai_lines]:
                qinghai_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in xizang_dictionary) and channel_address not in [x.split(',')[1] for x in xizang_lines]:
                xizang_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in news_dictionary) and channel_address not in [x.split(',')[1] for x in news_lines]:
                news_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in shuzi_dictionary) and channel_address not in [x.split(',')[1] for x in shuzi_lines]:
                shuzi_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in dianying_dictionary) and channel_address not in [x.split(',')[1] for x in dianying_lines]:
                dianying_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in jieshuo_dictionary) and channel_address not in [x.split(',')[1] for x in jieshuo_lines]:
                jieshuo_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in zongyi_dictionary) and channel_address not in [x.split(',')[1] for x in zongyi_lines]:
                zongyi_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in huya_dictionary) and channel_address not in [x.split(',')[1] for x in huya_lines]:
                huya_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in douyu_dictionary) and channel_address not in [x.split(',')[1] for x in douyu_lines]:
                douyu_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in xianggang_dictionary) and channel_address not in [x.split(',')[1] for x in xianggang_lines]:
                xianggang_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in aomen_dictionary) and channel_address not in [x.split(',')[1] for x in aomen_lines]:
                aomen_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in china_dictionary) and channel_address not in [x.split(',')[1] for x in china_lines]:
                china_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in guoji_dictionary) and channel_address not in [x.split(',')[1] for x in guoji_lines]:
                guoji_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in gangaotai_dictionary) and channel_address not in [x.split(',')[1] for x in gangaotai_lines]:
                gangaotai_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in dianshiju_dictionary) and channel_address not in [x.split(',')[1] for x in dianshiju_lines]:
                dianshiju_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in radio_dictionary) and channel_address not in [x.split(',')[1] for x in radio_lines]:
                radio_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in donghuapian_dictionary) and channel_address not in [x.split(',')[1] for x in donghuapian_lines]:
                donghuapian_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in jilupian_dictionary) and channel_address not in [x.split(',')[1] for x in jilupian_lines]:
                jilupian_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in tiyu_dictionary) and channel_address not in [x.split(',')[1] for x in tiyu_lines]:
                tiyu_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in tiyusaishi_dictionary) and channel_address not in [x.split(',')[1] for x in tiyusaishi_lines]:
                tiyusaishi_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in youxi_dictionary) and channel_address not in [x.split(',')[1] for x in youxi_lines]:
                youxi_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in xiqu_dictionary) and channel_address not in [x.split(',')[1] for x in xiqu_lines]:
                xiqu_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in yinyue_dictionary) and channel_address not in [x.split(',')[1] for x in yinyue_lines]:
                yinyue_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in chunwan_dictionary) and channel_address not in [x.split(',')[1] for x in chunwan_lines]:
                chunwan_lines.append(process_name_string(line.strip()))
            elif any(name in channel_name for name in zhibozhongguo_dictionary) and channel_address not in [x.split(',')[1] for x in zhibozhongguo_lines]:
                zhibozhongguo_lines.append(process_name_string(line.strip()))
            else:
                if channel_address not in other_lines_url:
                    other_lines_url.append(channel_address)
                    other_lines.append(line.strip())

# 获取随机User-Agent
def get_random_user_agent():
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36",
    ]
    return random.choice(USER_AGENTS)

# 处理URL
def process_url(url):
    try:
        other_lines.append("◆◆◆　" + url)
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3')
        with urllib.request.urlopen(req) as response:
            data = response.read()
            text = data.decode('utf-8')
            text = text.strip()
            is_m3u = text.startswith("#EXTM3U") or text.startswith("#EXTINF")
            if get_url_file_extension(url) == ".m3u" or get_url_file_extension(url) == ".m3u8" or is_m3u:
                text = convert_m3u_to_txt(text)
            lines = text.split('\n')
            print(f"行数: {len(lines)}")
            for line in lines:
                if "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                    if "#" not in line:
                        process_channel_line(line)
                    else:
                        channel_name, channel_address = line.split(',', 1)
                        url_list = channel_address.split('#')
                        for channel_url in url_list:
                            newline = f'{channel_name},{channel_url}'
                            process_channel_line(newline)
            other_lines.append('\n')
    except Exception as e:
        print(f"处理URL时发生错误：{e}")

# 获取当前工作目录
current_directory = os.getcwd()

# 读取各频道分类的字典文件
beijing_dictionary = read_txt_to_array('scripts/livesource/地方台/北京.txt')
shanghai_dictionary = read_txt_to_array('scripts/livesource/地方台/上海.txt')
tianjin_dictionary = read_txt_to_array('scripts/livesource/地方台/天津.txt')
chongqing_dictionary = read_txt_to_array('scripts/livesource/地方台/重庆.txt')
guangdong_dictionary = read_txt_to_array('scripts/livesource/地方台/广东.txt')
jiangsu_dictionary = read_txt_to_array('scripts/livesource/地方台/江苏.txt')
zhejiang_dictionary = read_txt_to_array('scripts/livesource/地方台/浙江.txt')
shandong_dictionary = read_txt_to_array('scripts/livesource/地方台/山东.txt')
henan_dictionary = read_txt_to_array('scripts/livesource/地方台/河南.txt')
sichuan_dictionary = read_txt_to_array('scripts/livesource/地方台/四川.txt')
hebei_dictionary = read_txt_to_array('scripts/livesource/地方台/河北.txt')
hunan_dictionary = read_txt_to_array('scripts/livesource/地方台/湖南.txt')
hubei_dictionary = read_txt_to_array('scripts/livesource/地方台/湖北.txt')
anhui_dictionary = read_txt_to_array('scripts/livesource/地方台/安徽.txt')
fujian_dictionary = read_txt_to_array('scripts/livesource/地方台/福建.txt')
shanxi1_dictionary = read_txt_to_array('scripts/livesource/地方台/陕西.txt')
liaoning_dictionary = read_txt_to_array('scripts/livesource/地方台/辽宁.txt')
jiangxi_dictionary = read_txt_to_array('scripts/livesource/地方台/江西.txt')
heilongjiang_dictionary = read_txt_to_array('scripts/livesource/地方台/黑龙江.txt')
jilin_dictionary = read_txt_to_array('scripts/livesource/地方台/吉林.txt')
shanxi2_dictionary = read_txt_to_array('scripts/livesource/地方台/山西.txt')
guangxi_dictionary = read_txt_to_array('scripts/livesource/地方台/广西.txt')
yunnan_dictionary = read_txt_to_array('scripts/livesource/地方台/云南.txt')
guizhou_dictionary = read_txt_to_array('scripts/livesource/地方台/贵州.txt')
gansu_dictionary = read_txt_to_array('scripts/livesource/地方台/甘肃.txt')
neimenggu_dictionary = read_txt_to_array('scripts/livesource/地方台/内蒙.txt')
xinjiang_dictionary = read_txt_to_array('scripts/livesource/地方台/新疆.txt')
hainan_dictionary = read_txt_to_array('scripts/livesource/地方台/海南.txt')
ningxia_dictionary = read_txt_to_array('scripts/livesource/地方台/宁夏.txt')
qinghai_dictionary = read_txt_to_array('scripts/livesource/地方台/青海.txt')
xizang_dictionary = read_txt_to_array('scripts/livesource/地方台/西藏.txt')
news_dictionary = read_txt_to_array('scripts/livesource/主频道/新闻.txt')
shuzi_dictionary = read_txt_to_array('scripts/livesource/主频道/数字.txt')
dianying_dictionary = read_txt_to_array('scripts/livesource/主频道/电影.txt')
jieshuo_dictionary = read_txt_to_array('scripts/livesource/主频道/解说.txt')
zongyi_dictionary = read_txt_to_array('scripts/livesource/主频道/综艺.txt')
huya_dictionary = read_txt_to_array('scripts/livesource/地方台/虎牙直播.txt')
douyu_dictionary = read_txt_to_array('scripts/livesource/地方台/斗鱼直播.txt')
xianggang_dictionary = read_txt_to_array('scripts/livesource/主频道/香港.txt')
aomen_dictionary = read_txt_to_array('scripts/livesource/主频道/澳门.txt')
china_dictionary = read_txt_to_array('scripts/livesource/主频道/中国.txt')
guoji_dictionary = read_txt_to_array('scripts/livesource/主频道/国际.txt')
gangaotai_dictionary = read_txt_to_array('scripts/livesource/主频道/港澳台.txt')
dianshiju_dictionary = read_txt_to_array('scripts/livesource/主频道/电视剧.txt')
radio_dictionary = read_txt_to_array('scripts/livesource/主频道/收音机.txt')
donghuapian_dictionary = read_txt_to_array('scripts/livesource/主频道/动画片.txt')
jilupian_dictionary = read_txt_to_array('scripts/livesource/主频道/记录片.txt')
tiyu_dictionary = read_txt_to_array('scripts/livesource/主频道/体育.txt')
tiyusaishi_dictionary = read_txt_to_array('scripts/livesource/主频道/体育赛事.txt')
youxi_dictionary = read_txt_to_array('scripts/livesource/主频道/游戏.txt')
xiqu_dictionary = read_txt_to_array('scripts/livesource/主频道/戏曲.txt')
yinyue_dictionary = read_txt_to_array('scripts/livesource/主频道/音乐.txt')
chunwan_dictionary = read_txt_to_array('scripts/livesource/主频道/春晚.txt')
zhibozhongguo_dictionary = read_txt_to_array('scripts/livesource/主频道/直播中国.txt')

# 加载频道名称修正文件
def load_corrections_name(filename):
    corrections = {}
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip():
                continue
            parts = line.strip().split(',')
            correct_name = parts[0]
            for name in parts[1:]:
                corrections[name] = correct_name
    return corrections

corrections_name = load_corrections_name('scripts/livesource/corrections_name.txt')

# 修正频道名称数据
def correct_name_data(corrections, data):
    corrected_data = []
    for line in data:
        line = line.strip()
        if ',' not in line:
            continue
        name, url = line.split(',', 1)
        if name in corrections and name != corrections[name]:
            name = corrections[name]
        corrected_data.append(f"{name},{url}")
    return corrected_data

# 数据排序
def sort_data(order, data):
    order_dict = {name: i for i, name in enumerate(order)}
    def sort_key(line):
        name = line.split(',')[0]
        return order_dict.get(name, len(order))
    sorted_data = sorted(data, key=sort_key)
    return sorted_data

# 处理URL列表
urls = read_txt_to_array('scripts/livesource/urls-daily.txt')
for url in urls:
    if url.startswith("http"):
        if "{MMdd}" in url:
            current_date_str = datetime.now().strftime("%m%d")
            url = url.replace("{MMdd}", current_date_str)
        if "{MMdd-1}" in url:
            yesterday_date_str = (datetime.now() - timedelta(days=1)).strftime("%m%d")
            url = url.replace("{MMdd-1}", yesterday_date_str)
        print(f"处理URL: {url}")
        process_url(url)

# 提取数字用于排序
def extract_number(s):
    num_str = s.split(',')[0].split('-')[1]
    numbers = re.findall(r'\d+', num_str)
    return int(numbers[-1]) if numbers else 999

# 自定义排序函数
def custom_sort(s):
    if "CCTV-4K" in s:
        return 2
    elif "CCTV-8K" in s:
        return 3
    elif "(4K)" in s:
        return 1
    else:
        return 0

# 处理白名单
print(f"ADD whitelist_auto.txt")
whitelist_auto_lines = read_txt_to_array('scripts/livesource/blacklist/whitelist_auto.txt')
for whitelist_line in whitelist_auto_lines:
    if "#genre#" not in whitelist_line and "," in whitelist_line and "://" in whitelist_line:
        whitelist_parts = whitelist_line.split(",")
        try:
            response_time = float(whitelist_parts[0].replace("ms", ""))
        except ValueError:
            print(f"response_time转换失败: {whitelist_line}")
            response_time = 60000
        if response_time < 2000:
            process_channel_line(",".join(whitelist_parts[1:]))

# HTTP请求函数
def get_http_response(url, timeout=8, retries=2, backoff_factor=1.0):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                data = response.read()
                return data.decode('utf-8')
        except urllib.error.HTTPError as e:
            print(f"[HTTPError] Code: {e.code}, URL: {url}")
            break
        except urllib.error.URLError as e:
            print(f"[URLError] Reason: {e.reason}, Attempt: {attempt + 1}")
        except socket.timeout:
            print(f"[Timeout] URL: {url}, Attempt: {attempt + 1}")
        except Exception as e:
            print(f"[Exception] {type(e).__name__}: {e}, Attempt: {attempt + 1}")
        if attempt < retries - 1:
            time.sleep(backoff_factor * (2 ** attempt))
    return None

# 从随机文件中获取URL
def get_random_url(file_path):
    urls = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            url = line.strip().split(',')[-1]
            urls.append(url)
    return random.choice(urls) if urls else None

# 获取北京时间
utc_time = datetime.now(timezone.utc)
beijing_time = utc_time + timedelta(hours=8)
formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")

# 生成每日推荐
daily_mtv = "推荐," + get_random_url('scripts/livesource/手工区/今日推荐.txt')

# 关于视频信息
about_video1 = "https://gitee.com/xiaoran67/@@@@"
about_video2 = "https://gitee.com/xiaoran67/@@@@"

version = formatted_time + "," + about_video1
about = "潇然," + daily_mtv

# 处理手工区数据
print(f"处理手工区...")
# 初始化手工区变量
hubei_lines = hubei_lines + read_txt_to_array('scripts/livesource/手工区/湖北频道.txt')

# 定义输出文件路径
output_full = os.path.join(output_dir, "full.txt")
output_lite = os.path.join(output_dir, "lite.txt") 
output_custom = os.path.join(output_dir, "custom.txt")
others_file = os.path.join(output_dir, "others.txt")

# 构建完整版输出内容 (包含全部频道)
all_lines_full = ["更新时间,#genre#"] + [version] + [about] + [daily_mtv] + ['\n'] + \
                ["🏛️央视频道,#genre#"] + yangshi_lines + ['\n'] + \
                ["🛰️卫视频道,#genre#"] + weishi_lines + ['\n'] + \
                ["📍北京频道,#genre#"] + beijing_lines + ['\n'] + \
                ["📍上海频道,#genre#"] + shanghai_lines + ['\n'] + \
                ["📍天津频道,#genre#"] + tianjin_lines + ['\n'] + \
                ["📍重庆频道,#genre#"] + chongqing_lines + ['\n'] + \
                ["📍广东频道,#genre#"] + guangdong_lines + ['\n'] + \
                ["📍江苏频道,#genre#"] + jiangsu_lines + ['\n'] + \
                ["📍浙江频道,#genre#"] + zhejiang_lines + ['\n'] + \
                ["📍山东频道,#genre#"] + shandong_lines + ['\n'] + \
                ["📍河南频道,#genre#"] + henan_lines + ['\n'] + \
                ["📍四川频道,#genre#"] + sichuan_lines + ['\n'] + \
                ["📍河北频道,#genre#"] + hebei_lines + ['\n'] + \
                ["📍湖南频道,#genre#"] + hunan_lines + ['\n'] + \
                ["📍湖北频道,#genre#"] + hubei_lines + ['\n'] + \
                ["📍安徽频道,#genre#"] + anhui_lines + ['\n'] + \
                ["📍福建频道,#genre#"] + fujian_lines + ['\n'] + \
                ["📍陕西频道,#genre#"] + shanxi1_lines + ['\n'] + \
                ["📍辽宁频道,#genre#"] + liaoning_lines + ['\n'] + \
                ["📍江西频道,#genre#"] + jiangxi_lines + ['\n'] + \
                ["📍黑龙江频道,#genre#"] + heilongjiang_lines + ['\n'] + \
                ["📍吉林频道,#genre#"] + jilin_lines + ['\n'] + \
                ["📍山西频道,#genre#"] + shanxi2_lines + ['\n'] + \
                ["📍广西频道,#genre#"] + guangxi_lines + ['\n'] + \
                ["📍云南频道,#genre#"] + yunnan_lines + ['\n'] + \
                ["📍贵州频道,#genre#"] + guizhou_lines + ['\n'] + \
                ["📍甘肃频道,#genre#"] + gansu_lines + ['\n'] + \
                ["📍内蒙古频道,#genre#"] + neimenggu_lines + ['\n'] + \
                ["📍新疆频道,#genre#"] + xinjiang_lines + ['\n'] + \
                ["📍海南频道,#genre#"] + hainan_lines + ['\n'] + \
                ["📍宁夏频道,#genre#"] + ningxia_lines + ['\n'] + \
                ["📍青海频道,#genre#"] + qinghai_lines + ['\n'] + \
                ["📍西藏频道,#genre#"] + xizang_lines + ['\n'] + \
                ["📰新闻频道,#genre#"] + news_lines + ['\n'] + \
                ["🔢数字频道,#genre#"] + shuzi_lines + ['\n'] + \
                ["🎬电影频道,#genre#"] + dianying_lines + ['\n'] + \
                ["🎙️解说频道,#genre#"] + jieshuo_lines + ['\n'] + \
                ["🎭综艺频道,#genre#"] + zongyi_lines + ['\n'] + \
                ["🐯虎牙直播,#genre#"] + huya_lines + ['\n'] + \
                ["🐟斗鱼直播,#genre#"] + douyu_lines + ['\n'] + \
                ["🇭🇰香港频道,#genre#"] + xianggang_lines + ['\n'] + \
                ["🇲🇴澳门频道,#genre#"] + aomen_lines + ['\n'] + \
                ["🇨🇳中国频道,#genre#"] + china_lines + ['\n'] + \
                ["🌍国际频道,#genre#"] + guoji_lines + ['\n'] + \
                ["🏙️港澳台频道,#genre#"] + gangaotai_lines + ['\n'] + \
                ["📺电视剧频道,#genre#"] + dianshiju_lines + ['\n'] + \
                ["📻收音机频道,#genre#"] + radio_lines + ['\n'] + \
                ["🐰动画片频道,#genre#"] + donghuapian_lines + ['\n'] + \
                ["🎞️纪录片频道,#genre#"] + jilupian_lines + ['\n'] + \
                ["⚽体育频道,#genre#"] + tiyu_lines + ['\n'] + \
                ["🏆体育赛事,#genre#"] + tiyusaishi_lines + ['\n'] + \
                ["🎮游戏频道,#genre#"] + youxi_lines + ['\n'] + \
                ["🎭戏曲频道,#genre#"] + xiqu_lines + ['\n'] + \
                ["🎵音乐频道,#genre#"] + yinyue_lines + ['\n'] + \
                ["🎉春晚频道,#genre#"] + chunwan_lines + ['\n'] + \
                ["🇨🇳直播中国,#genre#"] + zhibozhongguo_lines + ['\n'] + \
                ["📺其他频道,#genre#"] + other_lines + ['\n']

# 构建精简版输出内容 (只包含主要频道)
all_lines_lite = ["更新时间,#genre#"] + [version] + [about] + [daily_mtv] + ['\n'] + \
                ["🏛️央视频道,#genre#"] + yangshi_lines + ['\n'] + \
                ["🛰️卫视频道,#genre#"] + weishi_lines + ['\n'] + \
                ["📍北京频道,#genre#"] + beijing_lines + ['\n'] + \
                ["📍上海频道,#genre#"] + shanghai_lines + ['\n'] + \
                ["📍广东频道,#genre#"] + guangdong_lines + ['\n'] + \
                ["📍江苏频道,#genre#"] + jiangsu_lines + ['\n'] + \
                ["📍浙江频道,#genre#"] + zhejiang_lines + ['\n'] + \
                ["🎬电影频道,#genre#"] + dianying_lines + ['\n'] + \
                ["⚽体育频道,#genre#"] + tiyu_lines + ['\n'] + \
                ["🎵音乐频道,#genre#"] + yinyue_lines + ['\n']

# 构建定制版输出内容 (根据需求自定义)
all_lines_custom = ["更新时间,#genre#"] + [version] + [about] + [daily_mtv] + ['\n'] + \
                  ["🏛️央视频道,#genre#"] + yangshi_lines + ['\n'] + \
                  ["🛰️卫视频道,#genre#"] + weishi_lines + ['\n'] + \
                  ["🎬电影频道,#genre#"] + dianying_lines + ['\n'] + \
                  ["⚽体育频道,#genre#"] + tiyu_lines + ['\n'] + \
                  ["🏆体育赛事,#genre#"] + tiyusaishi_lines + ['\n'] + \
                  ["🎵音乐频道,#genre#"] + yinyue_lines + ['\n'] + \
                  ["📺电视剧频道,#genre#"] + dianshiju_lines + ['\n'] + \
                  ["🎭综艺频道,#genre#"] + zongyi_lines + ['\n']

# 保存文件
try:
    # 保存完整版
    with open(output_full, 'w', encoding='utf-8') as f:
        for line in all_lines_full:
            f.write(line + '\n')
    print(f"完整版已保存到文件: {output_full}")

    # 保存精简版
    with open(output_lite, 'w', encoding='utf-8') as f:
        for line in all_lines_lite:
            f.write(line + '\n')
    print(f"精简版已保存到文件: {output_lite}")

    # 保存定制版
    with open(output_custom, 'w', encoding='utf-8') as f:
        for line in all_lines_custom:
            f.write(line + '\n')
    print(f"定制版已保存到文件: {output_custom}")

    # 保存其他频道
    with open(others_file, 'w', encoding='utf-8') as f:
        for line in other_lines:
            f.write(line + '\n')
    print(f"其他频道已保存到文件: {others_file}")

except Exception as e:
    print(f"保存文件时发生错误：{e}")

# 读取频道logo
channels_logos = read_txt_to_array('scripts/livesource/logo.txt')

# 根据频道名称获取logo
def get_logo_by_channel_name(channel_name):
    for line in channels_logos:
        if not line.strip():
            continue
        name, url = line.split(',')
        if name == channel_name:
            return url
    return None

# 生成M3U文件
def make_m3u(txt_file, m3u_file):
    try:
        output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'
        with open(txt_file, "r", encoding='utf-8') as file:
            input_text = file.read()
        lines = input_text.strip().split("\n")
        group_name = ""
        for line in lines:
            parts = line.split(",")
            if len(parts) == 2 and "#genre#" in line:
                group_name = parts[0]
            elif len(parts) == 2:
                channel_name = parts[0]
                channel_url = parts[1]
                logo_url = get_logo_by_channel_name(channel_name)
                if logo_url is None:
                    output_text += f"#EXTINF:-1 group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
                else:
                    output_text += f"#EXTINF:-1  tvg-name=\"{channel_name}\" tvg-logo=\"{logo_url}\"  group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
        with open(f"{m3u_file}", "w", encoding='utf-8') as file:
            file.write(output_text)
        print(f"M3U文件 '{m3u_file}' 生成成功。")
    except Exception as e:
        print(f"发生错误: {e}")

# 为所有版本生成对应的M3U文件
make_m3u(output_full, output_full.replace(".txt", ".m3u"))
make_m3u(output_lite, output_lite.replace(".txt", ".m3u")) 
make_m3u(output_custom, output_custom.replace(".txt", ".m3u"))

# 计算执行时间
timeend = datetime.now()
elapsed_time = timeend - timestart
total_seconds = elapsed_time.total_seconds()
minutes = int(total_seconds // 60)
seconds = int(total_seconds % 60)
timestart_str = timestart.strftime("%Y%m%d_%H_%M_%S")
timeend_str = timeend.strftime("%Y%m%d_%H_%M_%S")

# 输出统计信息
print(f"开始时间: {timestart_str}")
print(f"结束时间: {timeend_str}")
print(f"执行时间: {minutes} 分 {seconds} 秒")

combined_blacklist_hj = len(combined_blacklist)
full_lines_hj = len(all_lines_full)
lite_lines_hj = len(all_lines_lite)
custom_lines_hj = len(all_lines_custom)
other_lines_hj = len(other_lines)

print(f"黑名单行数: {combined_blacklist_hj}")
print(f"完整版行数: {full_lines_hj}")
print(f"精简版行数: {lite_lines_hj}") 
print(f"定制版行数: {custom_lines_hj}")
print(f"其他源行数: {other_lines_hj}")

print("🎉 所有文件生成完成！")
print(f"📁 完整版: {output_full} 和 {output_full.replace('.txt', '.m3u')}")
print(f"📁 精简版: {output_lite} 和 {output_lite.replace('.txt', '.m3u')}")
print(f"📁 定制版: {output_custom} 和 {output_custom.replace('.txt', '.m3u')}")