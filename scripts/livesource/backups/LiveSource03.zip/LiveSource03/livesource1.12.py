"""
直播源处理脚本 - 完整优化版
功能：从多个URL源获取直播源，进行分类、去重、格式化处理
作者：xiaoranmuze
版本：2.0
支持多分类：频道可以出现在多个相关分类中
支持黑白名单：精确URL匹配和域名级过滤
"""

import urllib.request
from urllib.parse import urlparse
import re
import os
from datetime import datetime, timedelta, timezone
import random
import opencc
import socket
import time
import concurrent.futures

# 创建输出目录
os.makedirs('output', exist_ok=True)

def traditional_to_simplified(text: str) -> str:
    """繁体中文转简体中文"""
    converter = opencc.OpenCC('t2s')
    return converter.convert(text)

# 记录开始时间
timestart = datetime.now()

def read_txt_to_array(file_name):
    """读取文本文件到数组"""
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            return [line.strip() for line in lines if line.strip()]
    except FileNotFoundError:
        print(f"File '{file_name}' not found.")
        return []
    except Exception as e:
        print(f"An error occurred: {e}")
        return []

def read_blacklist_from_txt(file_path):
    """读取黑名单文件 - 适配新格式"""
    blacklist_urls = []
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()
        
        for line in lines:
            if line.strip() and ',' in line and '://' in line:
                # 跳过标题行
                if '#genre#' in line or '更新时间' in line:
                    continue
                # 格式：频道名称,URL
                parts = line.split(',')
                if len(parts) >= 2:
                    url = parts[1].strip()
                    if url and url.startswith(('http://', 'https://', 'rtmp://')):
                        blacklist_urls.append(url)
        
        return blacklist_urls
    except Exception as e:
        print(f"读取黑名单文件错误 {file_path}: {e}")
        return []

def read_whitelist_from_txt(file_path):
    """读取白名单文件 - 适配新格式"""
    whitelist_data = {}  # {url: response_time}
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()
        
        for line in lines:
            if line.strip() and ',' in line and '://' in line:
                # 跳过标题行
                if '#genre#' in line or '更新时间' in line:
                    continue
                
                parts = line.split(',')
                if len(parts) >= 3:
                    # 格式：响应时间,频道名称,URL
                    try:
                        response_time_str = parts[0].replace('ms', '').strip()
                        response_time = float(response_time_str)
                        url = parts[2].strip()
                        if url and url.startswith(('http://', 'https://', 'rtmp://')):
                            whitelist_data[url] = response_time
                    except ValueError:
                        # 如果响应时间转换失败，继续处理URL
                        url = parts[-1].strip()
                        if url and url.startswith(('http://', 'https://', 'rtmp://')):
                            whitelist_data[url] = 1000  # 默认值
                elif len(parts) == 2:
                    # 格式：频道名称,URL
                    url = parts[1].strip()
                    if url and url.startswith(('http://', 'https://', 'rtmp://')):
                        whitelist_data[url] = 1000  # 默认值
        
        return whitelist_data
    except Exception as e:
        print(f"读取白名单文件错误 {file_path}: {e}")
        return {}

# 读取黑白名单
print("📋 加载黑白名单...")
blacklist_auto = read_blacklist_from_txt('scripts/livesource/blacklist/blacklist_auto.txt') 
blacklist_manual = read_blacklist_from_txt('scripts/livesource/blacklist/blacklist_manual.txt') 
combined_blacklist = set(blacklist_auto + blacklist_manual)
print(f"  ✅ 黑名单: {len(combined_blacklist)} 条规则")

whitelist_data = read_whitelist_from_txt('scripts/livesource/blacklist/whitelist_auto.txt')
whitelist_set = set(whitelist_data.keys())
print(f"  ✅ 白名单: {len(whitelist_set)} 个受信任URL")

def extract_domain_from_url(url):
    """从URL中提取域名"""
    try:
        parsed = urlparse(url)
        domain = parsed.netloc
        # 移除端口号
        if ':' in domain:
            domain = domain.split(':')[0]
        return domain
    except Exception:
        return None

# 域名级黑名单
domain_blacklist = set()
for url in combined_blacklist:
    domain = extract_domain_from_url(url)
    if domain:
        domain_blacklist.add(domain)
print(f"  🌐 域名黑名单: {len(domain_blacklist)} 个域名")


def is_url_blacklisted(channel_name, channel_url):
    """
    智能黑名单检查
    :param channel_name: 频道名称
    :param channel_url: 频道URL
    :return: 是否被黑名单标记
    """
    # 1. 白名单优先（最高优先级）
    if channel_url in whitelist_set:
        return False
    
    # 2. 精确URL黑名单检查
    if channel_url in combined_blacklist:
        return True
    
    # 3. 域名级黑名单检查
    domain = extract_domain_from_url(channel_url)
    if domain and domain in domain_blacklist:
        return True
    
    return False

# 初始化各分类频道列表
yangshi_lines = []
weishi_lines = []

beijing_lines = []
shanghai_lines = []
tianjin_lines = []
chongqing_lines = []
guangdong_lines = []
jiangsu_lines = []
zhejiang_lines = []
shandong_lines = []
henan_lines = []
sichuan_lines = []
hebei_lines = []
hunan_lines = []
hubei_lines = []
anhui_lines = []
fujian_lines = []
shanxi1_lines = []
liaoning_lines = []
jiangxi_lines = []
heilongjiang_lines = []
jilin_lines = []
shanxi2_lines = []
guangxi_lines = []
yunnan_lines = []
guizhou_lines = []
gansu_lines = []
neimenggu_lines = []
xinjiang_lines = []
hainan_lines = []
ningxia_lines = []
qinghai_lines = []
xizang_lines = []

news_lines = []
shuzi_lines = []
dianying_lines = []
jieshuo_lines = []
zongyi_lines = []
huya_lines = []
douyu_lines = []
xianggang_lines = []
aomen_lines = []
china_lines = []
guoji_lines = []
gangaotai_lines = []
dianshiju_lines = []
radio_lines = []
donghuapian_lines = []
jilupian_lines = []
tiyu_lines = []
tiyusaishi_lines = []
youxi_lines = []
xiqu_lines = []
yinyue_lines = []
chunwan_lines = []
zhibozhongguo_lines = []

other_lines = []
other_lines_url = []

# 分类统计
classification_stats = {}

def process_name_string(input_str):
    """处理频道名称字符串"""
    parts = input_str.split(',')
    processed_parts = [process_part(part) for part in parts]
    return ','.join(processed_parts)

def process_part(part_str):
    """处理单个频道名称部分"""
    if "CCTV" in part_str and "://" not in part_str:
        part_str = part_str.replace("IPV6", "").replace("PLUS", "+").replace("1080", "")
        filtered_str = ''.join(char for char in part_str if char.isdigit() or char == 'K' or char == '+')
        
        if not filtered_str.strip():
            filtered_str = part_str.replace("CCTV", "")

        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2: 
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)

        return "CCTV" + filtered_str 
        
    elif "卫视" in part_str:
        return re.sub(r'卫视「.*」', '卫视', part_str)
    
    return part_str

def get_url_file_extension(url):
    """获取URL的文件扩展名"""
    parsed_url = urlparse(url)
    return os.path.splitext(parsed_url.path)[1]

def convert_m3u_to_txt(m3u_content):
    """将M3U格式转换为TXT格式"""
    lines = m3u_content.split('\n')
    txt_lines = []
    channel_name = ""
    
    for line in lines:
        if line.startswith("#EXTM3U"):
            continue
        elif line.startswith("#EXTINF"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith("http") or line.startswith("rtmp") or line.startswith("p3p"):
            txt_lines.append(f"{channel_name},{line.strip()}")
        
        if "#genre#" not in line and "," in line and "://" in line:
            pattern = r'^[^,]+,[^\s]+://[^\s]+$'
            if bool(re.match(pattern, line)):
                txt_lines.append(line)
    
    return '\n'.join(txt_lines)

def enhanced_check_url_existence(data_list, url, channel_name=None):
    """
    增强的去重检查 - 分类内部去重，允许跨分类重复
    """
    for item in data_list:
        if ',' in item:
            parts = item.split(',', 1)
            if len(parts) == 2:
                existing_url = parts[1].strip()
                if existing_url == url:
                    if channel_name and parts[0].strip() == channel_name:
                        return True
                    elif not channel_name:
                        return True
    return False

def clean_url(url):
    """清理URL，移除$符号及其后面的内容"""
    last_dollar_index = url.rfind('$')
    return url[:last_dollar_index] if last_dollar_index != -1 else url

# 频道名称清理列表
removal_list = ["_电信", "电信", "高清", "频道", "（HD）", "-HD", "英陆", "_ITV", "(北美)", "(HK)", "AKtv", "「IPV4」", "「IPV6」",
                "频陆", "备陆", "壹陆", "贰陆", "叁陆", "肆陆", "伍陆", "陆陆", "柒陆", "频晴", "频粤", "[超清]", "高清", "超清", "标清", "斯特",
                "粤陆", "国陆", "肆柒", "频英", "频特", "频国", "频壹", "频贰", "肆贰", "频测", "咪咕", "闽特", "高特", "频高", "频标", "汝阳", 
                "[HD]", "[BD]", "[SD]", "[VGA]"]

def clean_channel_name(channel_name, removal_list):
    """清理频道名称中的特定字符"""
    for item in removal_list:
        channel_name = channel_name.replace(item, "")

    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]
    
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]

    return channel_name

def normalize_channel_name(channel_name):
    """标准化频道名称用于去重比较"""
    channel_name = channel_name.strip()
    channel_name = re.sub(r'\s+', ' ', channel_name)
    
    patterns_to_remove = [
        r'\(\d+\)$', r'\[\d+\]$', r'-\d+$', r'_\d+$',
    ]
    
    for pattern in patterns_to_remove:
        channel_name = re.sub(pattern, '', channel_name)
    
    return channel_name.strip()

def load_corrections_name(filename):
    """读取频道名称纠错文件"""
    corrections = {}
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip():
                continue
            parts = line.strip().split(',')
            correct_name = parts[0]
            for name in parts[1:]:
                corrections[name] = correct_name
    return corrections

def load_extended_alias_system():
    """加载扩展的别名系统"""
    corrections_name = load_corrections_name('scripts/livesource/corrections_name.txt')
    
    # 自动生成的常见变体
    auto_aliases = generate_auto_aliases()
    
    # 合并别名系统
    extended_aliases = {**corrections_name, **auto_aliases}
    
    print(f"  🔧 别名系统: {len(extended_aliases)} 条映射规则")
    return extended_aliases

def generate_auto_aliases():
    """自动生成常见名称变体"""
    auto_aliases = {}
    
    # CCTV 变体
    for i in range(1, 20):
        # 数字频道变体
        base_names = [f"CCTV{i}", f"CCTV-{i}", f"央视{i}", f"中央{i}", f"央视{i}套", f"中央{i}台"]
        for base in base_names:
            # 高清变体
            auto_aliases[f"{base}高清"] = f"CCTV{i}"
            auto_aliases[f"{base}HD"] = f"CCTV{i}"
            auto_aliases[f"{base} 高清"] = f"CCTV{i}"
            auto_aliases[f"{base} 超清"] = f"CCTV{i}"
            auto_aliases[f"{base} 标清"] = f"CCTV{i}"
    
    # 卫变体
    weishi_variants = {
        "湖南卫视": ["湖南台", "湖南电视台", "芒果台"],
        "浙江卫视": ["浙江台", "浙江电视台"], 
        "江苏卫视": ["江苏台", "江苏电视台"],
        "北京卫视": ["北京台", "北京电视台", "BTV"],
        "东方卫视": ["东方台", "上海东方", "番茄台"],
        "安徽卫视": ["安徽台", "安徽电视台"],
        "山东卫视": ["山东台", "山东电视台"],
        "天津卫视": ["天津台", "天津电视台"],
        "重庆卫视": ["重庆台", "重庆电视台"],
        "黑龙江卫视": ["黑龙江台", "黑龙江电视台"],
        "吉林卫视": ["吉林台", "吉林电视台"],
        "辽宁卫视": ["辽宁台", "辽宁电视台"],
        "四川卫视": ["四川台", "四川电视台"],
        "广东卫视": ["广东台", "广东电视台"],
        "深圳卫视": ["深圳台", "深圳电视台"],
        "湖北卫视": ["湖北台", "湖北电视台"],
        "河南卫视": ["河南台", "河南电视台"],
        "河北卫视": ["河北台", "河北电视台"],
        "陕西卫视": ["陕西台", "陕西电视台"],
        "山西卫视": ["山西台", "山西电视台"],
    }
    
    for correct_name, variants in weishi_variants.items():
        for variant in variants:
            auto_aliases[variant] = correct_name
    
    return auto_aliases

def preprocess_channel_name(channel_name, extended_aliases):
    """预处理频道名称（分类前）"""
    # 1. 繁体转简体
    channel_name = traditional_to_simplified(channel_name)
    
    # 2. 基础清理
    channel_name = clean_channel_name(channel_name, removal_list)
    
    # 3. 别名映射（用于分类匹配）
    for alias, correct_name in extended_aliases.items():
        if alias in channel_name:
            channel_name = correct_name
            break
    
    return channel_name

def get_final_display_name(original_name, corrections_name):
    """获取最终显示名称"""
    # 应用完整的名称纠错
    if original_name in corrections_name:
        return corrections_name[original_name]
    
    # 额外的名称美化
    name = traditional_to_simplified(original_name)
    name = clean_channel_name(name, removal_list)
    return name

def fuzzy_match_channel_name(input_name, dictionary_names, threshold=0.7):
    """
    模糊匹配频道名称
    """
    input_name = input_name.lower().strip()
    
    # 精确匹配优先
    for dict_name in dictionary_names:
        if dict_name.lower() in input_name or input_name in dict_name.lower():
            return dict_name
    
    # 分词匹配
    input_words = set(re.findall(r'[\u4e00-\u9fff]+|[a-zA-Z0-9]+', input_name))
    
    best_match = None
    best_score = 0
    
    for dict_name in dictionary_names:
        dict_words = set(re.findall(r'[\u4e00-\u9fff]+|[a-zA-Z0-9]+', dict_name.lower()))
        
        # 计算Jaccard相似度
        intersection = input_words.intersection(dict_words)
        union = input_words.union(dict_words)
        
        if union:
            similarity = len(intersection) / len(union)
            if similarity > best_score and similarity >= threshold:
                best_score = similarity
                best_match = dict_name
    
    return best_match

def enhanced_channel_classification(input_name, channel_url, extended_aliases):
    """
    增强的频道分类系统
    """
    # 1. 基础清理和别名映射
    cleaned_name = traditional_to_simplified(input_name)
    cleaned_name = clean_channel_name(cleaned_name, removal_list)
    
    # 2. 扩展别名映射
    display_name = cleaned_name
    for alias, correct_name in extended_aliases.items():
        if alias in cleaned_name:
            display_name = correct_name
            break
    
    # 3. 多级分类匹配
    classifications = []
    
    # 央视频道匹配
    if fuzzy_match_channel_name(cleaned_name, yangshi_dictionary) or \
       any(keyword in cleaned_name for keyword in ["CCTV", "央视", "中央"]):
        classifications.append("yangshi")
    
    # 卫视频道匹配
    weishi_match = fuzzy_match_channel_name(cleaned_name, weishi_dictionary)
    if weishi_match:
        classifications.append("weishi")
    
    # 地方台匹配
    local_categories = [
        ("beijing", beijing_dictionary, ["北京", "BTV"]),
        ("shanghai", shanghai_dictionary, ["上海", "东方", "上视"]),
        ("tianjin", tianjin_dictionary, ["天津"]),
        ("chongqing", chongqing_dictionary, ["重庆"]),
        ("guangdong", guangdong_dictionary, ["广东", "南方", "珠江"]),
        ("jiangsu", jiangsu_dictionary, ["江苏"]),
        ("zhejiang", zhejiang_dictionary, ["浙江"]),
        ("shandong", shandong_dictionary, ["山东"]),
        ("henan", henan_dictionary, ["河南"]),
        ("sichuan", sichuan_dictionary, ["四川"]),
        ("hebei", hebei_dictionary, ["河北"]),
        ("hunan", hunan_dictionary, ["湖南"]),
        ("hubei", hubei_dictionary, ["湖北"]),
        ("anhui", anhui_dictionary, ["安徽"]),
        ("fujian", fujian_dictionary, ["福建"]),
        ("shanxi1", shanxi1_dictionary, ["陕西"]),
        ("liaoning", liaoning_dictionary, ["辽宁"]),
        ("jiangxi", jiangxi_dictionary, ["江西"]),
        ("heilongjiang", heilongjiang_dictionary, ["黑龙江"]),
        ("jilin", jilin_dictionary, ["吉林"]),
        ("shanxi2", shanxi2_dictionary, ["山西"]),
        ("guangxi", guangxi_dictionary, ["广西"]),
        ("yunnan", yunnan_dictionary, ["云南"]),
        ("guizhou", guizhou_dictionary, ["贵州"]),
        ("gansu", gansu_dictionary, ["甘肃"]),
        ("neimenggu", neimenggu_dictionary, ["内蒙", "内蒙古"]),
        ("xinjiang", xinjiang_dictionary, ["新疆"]),
        ("hainan", hainan_dictionary, ["海南"]),
        ("ningxia", ningxia_dictionary, ["宁夏"]),
        ("qinghai", qinghai_dictionary, ["青海"]),
        ("xizang", xizang_dictionary, ["西藏"]),
    ]
    
    for category_key, dictionary, keywords in local_categories:
        if fuzzy_match_channel_name(cleaned_name, dictionary) or \
           any(keyword in cleaned_name for keyword in keywords):
            classifications.append(category_key)
    
    # 专业频道匹配
    professional_categories = [
        ("news", news_dictionary, ["新闻", "NEWS"]),
        ("dianying", dianying_dictionary, ["电影", "影院"]),
        ("tiyu", tiyu_dictionary, ["体育", "运动"]),
        ("zongyi", zongyi_dictionary, ["综艺", "娱乐"]),
        ("dianshiju", dianshiju_dictionary, ["电视剧", "剧集"]),
        ("donghuapian", donghuapian_dictionary, ["动画", "动漫", "卡通"]),
        ("jilupian", jilupian_dictionary, ["记录", "纪实", "纪录片"]),
        ("yinyue", yinyue_dictionary, ["音乐", "MTV"]),
        ("youxi", youxi_dictionary, ["游戏", "电竞"]),
    ]
    
    for category_key, dictionary, keywords in professional_categories:
        if fuzzy_match_channel_name(cleaned_name, dictionary) or \
           any(keyword in cleaned_name for keyword in keywords):
            classifications.append(category_key)
    
    return display_name, classifications

def process_channel_corrected(line, extended_aliases, corrections_name):
    """
    正确的频道处理逻辑
    - 支持多分类：频道可以出现在多个正常分类中
    - 纯净其他频道：只包含完全未分类的频道
    """
    if "#genre#" not in line and "#EXTINF:" not in line and "," in line and "://" in line:
        original_name = line.split(',')[0].strip()
        channel_address = clean_url(line.split(',')[1].strip())
        
        # 黑白名单检查
        if is_url_blacklisted(original_name, channel_address):
            return
        
        # 智能分类
        display_name, classifications = enhanced_channel_classification(
            original_name, channel_address, extended_aliases
        )
        
        # 获取最终显示名称
        final_display_name = get_final_display_name(display_name, corrections_name)
        processed_line = final_display_name + "," + channel_address
        
        # 分类标记：记录这个频道被分到了哪些分类
        classified_categories = []
        
        # 央视频道分类（支持多分类）
        if "yangshi" in classifications:
            if not enhanced_check_url_existence(yangshi_lines, channel_address):
                yangshi_lines.append(processed_line)
                classified_categories.append("yangshi")
        
        # 卫视频道分类（支持多分类）
        if "weishi" in classifications:
            if not enhanced_check_url_existence(weishi_lines, channel_address):
                weishi_lines.append(processed_line)
                classified_categories.append("weishi")
        
        # 地方台分类（支持多分类）
        local_category_mapping = [
            ("beijing", beijing_lines),
            ("shanghai", shanghai_lines),
            ("tianjin", tianjin_lines),
            ("chongqing", chongqing_lines),
            ("guangdong", guangdong_lines),
            ("jiangsu", jiangsu_lines),
            ("zhejiang", zhejiang_lines),
            ("shandong", shandong_lines),
            ("henan", henan_lines),
            ("sichuan", sichuan_lines),
            ("hebei", hebei_lines),
            ("hunan", hunan_lines),
            ("hubei", hubei_lines),
            ("anhui", anhui_lines),
            ("fujian", fujian_lines),
            ("shanxi1", shanxi1_lines),
            ("liaoning", liaoning_lines),
            ("jiangxi", jiangxi_lines),
            ("heilongjiang", heilongjiang_lines),
            ("jilin", jilin_lines),
            ("shanxi2", shanxi2_lines),
            ("guangxi", guangxi_lines),
            ("yunnan", yunnan_lines),
            ("guizhou", guizhou_lines),
            ("gansu", gansu_lines),
            ("neimenggu", neimenggu_lines),
            ("xinjiang", xinjiang_lines),
            ("hainan", hainan_lines),
            ("ningxia", ningxia_lines),
            ("qinghai", qinghai_lines),
            ("xizang", xizang_lines),
        ]
        
        for category_key, lines_list in local_category_mapping:
            if category_key in classifications:
                if not enhanced_check_url_existence(lines_list, channel_address):
                    lines_list.append(processed_line)
                    classified_categories.append(category_key)
        
        # 专业频道分类（支持多分类）
        professional_category_mapping = [
            ("news", news_lines),
            ("shuzi", shuzi_lines),
            ("dianying", dianying_lines),
            ("jieshuo", jieshuo_lines),
            ("zongyi", zongyi_lines),
            ("huya", huya_lines),
            ("douyu", douyu_lines),
            ("xianggang", xianggang_lines),
            ("aomen", aomen_lines),
            ("china", china_lines),
            ("guoji", guoji_lines),
            ("gangaotai", gangaotai_lines),
            ("dianshiju", dianshiju_lines),
            ("radio", radio_lines),
            ("donghuapian", donghuapian_lines),
            ("jilupian", jilupian_lines),
            ("tiyu", tiyu_lines),
            ("tiyusaishi", tiyusaishi_lines),
            ("youxi", youxi_lines),
            ("xiqu", xiqu_lines),
            ("yinyue", yinyue_lines),
            ("chunwan", chunwan_lines),
            ("zhibozhongguo", zhibozhongguo_lines),
        ]
        
        for category_key, lines_list in professional_category_mapping:
            if category_key in classifications:
                if not enhanced_check_url_existence(lines_list, channel_address):
                    lines_list.append(processed_line)
                    classified_categories.append(category_key)
        
        # 关键逻辑：只有完全未分类的频道才进入其他频道
        if not classified_categories:
            if not enhanced_check_url_existence(other_lines, channel_address):
                other_lines.append(processed_line)
                other_lines_url.append(channel_address)
        
        # 记录分类统计
        if classified_categories:
            for category in classified_categories:
                classification_stats[category] = classification_stats.get(category, 0) + 1

def get_random_user_agent():
    """获取随机User-Agent"""
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36",
    ]
    return random.choice(USER_AGENTS)

def process_url_corrected(url, extended_aliases, corrections_name):
    """使用正确分类逻辑处理URL"""
    try:
        other_lines.append("◆◆◆　" + url)
        
        req = urllib.request.Request(url)
        req.add_header('User-Agent', get_random_user_agent())

        with urllib.request.urlopen(req, timeout=10) as response:
            data = response.read()
            text = data.decode('utf-8').strip()

            # 格式转换
            if text.startswith("#EXTM3U") or text.startswith("#EXTINF"):
                text = convert_m3u_to_txt(text)

            # 处理每一行
            lines = text.split('\n')
            valid_channels = 0
            
            for line in lines:
                if is_valid_channel_line(line):
                    valid_channels += 1
                    process_channel_corrected(line, extended_aliases, corrections_name)
            
            print(f"  ✅ 处理了 {valid_channels} 个有效频道")
            other_lines.append('\n')

    except Exception as e:
        print(f"❌ 处理URL时发生错误：{e}")

def is_valid_channel_line(line):
    """检查是否为有效的频道行"""
    if "#genre#" in line or not line.strip():
        return False
    if "," not in line or "://" not in line:
        return False
    if "tvbus://" in line or "/udp/" in line:
        return False
    return True

def correct_final_cleanup_other_channels():
    """
    正确的最终清理：确保其他频道只包含完全未分类的频道
    """
    print("🧹 正确清理其他频道...")
    
    # 收集所有正常分类中的URL
    all_normal_category_urls = set()
    
    normal_category_lists = [
        yangshi_lines, weishi_lines, beijing_lines, shanghai_lines, tianjin_lines, chongqing_lines,
        guangdong_lines, jiangsu_lines, zhejiang_lines, shandong_lines, henan_lines, sichuan_lines,
        hebei_lines, hunan_lines, hubei_lines, anhui_lines, fujian_lines, shanxi1_lines, liaoning_lines,
        jiangxi_lines, heilongjiang_lines, jilin_lines, shanxi2_lines, guangxi_lines, yunnan_lines,
        guizhou_lines, gansu_lines, neimenggu_lines, xinjiang_lines, hainan_lines, ningxia_lines,
        qinghai_lines, xizang_lines, news_lines, shuzi_lines, dianying_lines, jieshuo_lines, zongyi_lines,
        huya_lines, douyu_lines, xianggang_lines, aomen_lines, china_lines, guoji_lines, gangaotai_lines,
        dianshiju_lines, radio_lines, donghuapian_lines, jilupian_lines, tiyu_lines, tiyusaishi_lines,
        youxi_lines, xiqu_lines, yinyue_lines, chunwan_lines, zhibozhongguo_lines
    ]
    
    for category_list in normal_category_lists:
        for line in category_list:
            if ',' in line and '://' in line:
                url = line.split(',')[1].strip()
                all_normal_category_urls.add(url)
    
    # 验证其他频道的纯净性
    initial_other_count = len([line for line in other_lines if ',' in line and '://' in line])
    contaminated_urls = []
    
    cleaned_other_lines = []
    for line in other_lines:
        if ',' in line and '://' in line:
            url = line.split(',')[1].strip()
            if url in all_normal_category_urls:
                contaminated_urls.append((line, url))
            else:
                cleaned_other_lines.append(line)
        else:
            cleaned_other_lines.append(line)
    
    # 报告污染情况
    if contaminated_urls:
        print(f"  ⚠️  发现 {len(contaminated_urls)} 个已分类频道错误出现在其他频道中")
    else:
        print("  ✅ 其他频道纯净：不包含任何已分类频道")
    
    final_other_count = len([line for line in cleaned_other_lines if ',' in line and '://' in line])
    print(f"  📊 其他频道: {initial_other_count} -> {final_other_count} 个频道")
    
    return cleaned_other_lines

def strict_sort_by_dictionary(data_lines, dictionary_list, category_name=""):
    """
    严格按照字典顺序排序
    """
    if not data_lines or not dictionary_list:
        return data_lines
    
    # 构建字典顺序映射
    order_dict = {}
    for idx, dict_item in enumerate(dictionary_list):
        if ',' in dict_item:
            dict_name = dict_item.split(',')[0].strip()
        else:
            dict_name = dict_item.strip()
        order_dict[dict_name] = idx
    
    # 分离频道行和其他行
    channel_entries = []
    other_lines = []
    
    for line in data_lines:
        if line.strip() and ',' in line and '://' in line:
            channel_name = line.split(',')[0].strip()
            channel_entries.append((channel_name, line))
        else:
            other_lines.append(line)
    
    # 严格按字典顺序排序
    def get_sort_key(item):
        channel_name, line = item
        # 精确匹配优先
        if channel_name in order_dict:
            return (0, order_dict[channel_name], channel_name)
        
        # 部分匹配
        for dict_name, order in order_dict.items():
            if dict_name in channel_name:
                return (1, order, channel_name)
        
        # 未匹配的放在最后
        return (2, len(order_dict), channel_name)
    
    # 排序
    sorted_entries = sorted(channel_entries, key=get_sort_key)
    sorted_lines = [line for _, line in sorted_entries]
    
    print(f"  ✅ {category_name}: 已排序 {len(sorted_entries)} 个频道")
    return other_lines + sorted_lines

def apply_dictionary_sorting_to_all_categories():
    """对所有分类应用字典排序"""
    print("🔧 开始严格字典排序...")
    
    # 央视频道排序
    yangshi_lines[:] = strict_sort_by_dictionary(yangshi_lines, yangshi_dictionary, "央视频道")
    
    # 卫视频道排序
    weishi_lines[:] = strict_sort_by_dictionary(weishi_lines, weishi_dictionary, "卫视频道")
    
    # 地方台排序
    beijing_lines[:] = strict_sort_by_dictionary(beijing_lines, beijing_dictionary, "北京频道")
    shanghai_lines[:] = strict_sort_by_dictionary(shanghai_lines, shanghai_dictionary, "上海频道")
    tianjin_lines[:] = strict_sort_by_dictionary(tianjin_lines, tianjin_dictionary, "天津频道")
    chongqing_lines[:] = strict_sort_by_dictionary(chongqing_lines, chongqing_dictionary, "重庆频道")
    guangdong_lines[:] = strict_sort_by_dictionary(guangdong_lines, guangdong_dictionary, "广东频道")
    jiangsu_lines[:] = strict_sort_by_dictionary(jiangsu_lines, jiangsu_dictionary, "江苏频道")
    zhejiang_lines[:] = strict_sort_by_dictionary(zhejiang_lines, zhejiang_dictionary, "浙江频道")
    shandong_lines[:] = strict_sort_by_dictionary(shandong_lines, shandong_dictionary, "山东频道")
    henan_lines[:] = strict_sort_by_dictionary(henan_lines, henan_dictionary, "河南频道")
    sichuan_lines[:] = strict_sort_by_dictionary(sichuan_lines, sichuan_dictionary, "四川频道")
    hebei_lines[:] = strict_sort_by_dictionary(hebei_lines, hebei_dictionary, "河北频道")
    hunan_lines[:] = strict_sort_by_dictionary(hunan_lines, hunan_dictionary, "湖南频道")
    hubei_lines[:] = strict_sort_by_dictionary(hubei_lines, hubei_dictionary, "湖北频道")
    anhui_lines[:] = strict_sort_by_dictionary(anhui_lines, anhui_dictionary, "安徽频道")
    fujian_lines[:] = strict_sort_by_dictionary(fujian_lines, fujian_dictionary, "福建频道")
    shanxi1_lines[:] = strict_sort_by_dictionary(shanxi1_lines, shanxi1_dictionary, "陕西频道")
    liaoning_lines[:] = strict_sort_by_dictionary(liaoning_lines, liaoning_dictionary, "辽宁频道")
    jiangxi_lines[:] = strict_sort_by_dictionary(jiangxi_lines, jiangxi_dictionary, "江西频道")
    heilongjiang_lines[:] = strict_sort_by_dictionary(heilongjiang_lines, heilongjiang_dictionary, "黑龙江频道")
    jilin_lines[:] = strict_sort_by_dictionary(jilin_lines, jilin_dictionary, "吉林频道")
    shanxi2_lines[:] = strict_sort_by_dictionary(shanxi2_lines, shanxi2_dictionary, "山西频道")
    guangxi_lines[:] = strict_sort_by_dictionary(guangxi_lines, guangxi_dictionary, "广西频道")
    yunnan_lines[:] = strict_sort_by_dictionary(yunnan_lines, yunnan_dictionary, "云南频道")
    guizhou_lines[:] = strict_sort_by_dictionary(guizhou_lines, guizhou_dictionary, "贵州频道")
    gansu_lines[:] = strict_sort_by_dictionary(gansu_lines, gansu_dictionary, "甘肃频道")
    neimenggu_lines[:] = strict_sort_by_dictionary(neimenggu_lines, neimenggu_dictionary, "内蒙频道")
    xinjiang_lines[:] = strict_sort_by_dictionary(xinjiang_lines, xinjiang_dictionary, "新疆频道")
    hainan_lines[:] = strict_sort_by_dictionary(hainan_lines, hainan_dictionary, "海南频道")
    ningxia_lines[:] = strict_sort_by_dictionary(ningxia_lines, ningxia_dictionary, "宁夏频道")
    qinghai_lines[:] = strict_sort_by_dictionary(qinghai_lines, qinghai_dictionary, "青海频道")
    xizang_lines[:] = strict_sort_by_dictionary(xizang_lines, xizang_dictionary, "西藏频道")
    
    # 其他分类排序
    news_lines[:] = strict_sort_by_dictionary(news_lines, news_dictionary, "新闻频道")
    shuzi_lines[:] = strict_sort_by_dictionary(shuzi_lines, shuzi_dictionary, "数字频道")
    dianying_lines[:] = strict_sort_by_dictionary(dianying_lines, dianying_dictionary, "电影频道")
    jieshuo_lines[:] = strict_sort_by_dictionary(jieshuo_lines, jieshuo_dictionary, "解说频道")
    zongyi_lines[:] = strict_sort_by_dictionary(zongyi_lines, zongyi_dictionary, "综艺频道")
    huya_lines[:] = strict_sort_by_dictionary(huya_lines, huya_dictionary, "虎牙直播")
    douyu_lines[:] = strict_sort_by_dictionary(douyu_lines, douyu_dictionary, "斗鱼直播")
    xianggang_lines[:] = strict_sort_by_dictionary(xianggang_lines, xianggang_dictionary, "香港频道")
    aomen_lines[:] = strict_sort_by_dictionary(aomen_lines, aomen_dictionary, "澳门频道")
    china_lines[:] = strict_sort_by_dictionary(china_lines, china_dictionary, "中国频道")
    guoji_lines[:] = strict_sort_by_dictionary(guoji_lines, guoji_dictionary, "国际频道")
    gangaotai_lines[:] = strict_sort_by_dictionary(gangaotai_lines, gangaotai_dictionary, "港澳台")
    dianshiju_lines[:] = strict_sort_by_dictionary(dianshiju_lines, dianshiju_dictionary, "电视剧")
    radio_lines[:] = strict_sort_by_dictionary(radio_lines, radio_dictionary, "收音机")
    donghuapian_lines[:] = strict_sort_by_dictionary(donghuapian_lines, donghuapian_dictionary, "动画片")
    jilupian_lines[:] = strict_sort_by_dictionary(jilupian_lines, jilupian_dictionary, "记录片")
    tiyu_lines[:] = strict_sort_by_dictionary(tiyu_lines, tiyu_dictionary, "体育频道")
    tiyusaishi_lines[:] = strict_sort_by_dictionary(tiyusaishi_lines, tiyusaishi_dictionary, "体育赛事")
    youxi_lines[:] = strict_sort_by_dictionary(youxi_lines, youxi_dictionary, "游戏频道")
    xiqu_lines[:] = strict_sort_by_dictionary(xiqu_lines, xiqu_dictionary, "戏曲频道")
    yinyue_lines[:] = strict_sort_by_dictionary(yinyue_lines, yinyue_dictionary, "音乐频道")
    chunwan_lines[:] = strict_sort_by_dictionary(chunwan_lines, chunwan_dictionary, "春晚频道")
    zhibozhongguo_lines[:] = strict_sort_by_dictionary(zhibozhongguo_lines, zhibozhongguo_dictionary, "直播中国")
    
    print("✅ 所有分类字典排序完成")

def final_deduplicate_lines(lines):
    """最终去重函数（分类内部去重）"""
    seen_channels = set()
    deduplicated = []
    
    for line in lines:
        if "#genre#" in line or line == '\n':
            deduplicated.append(line)
            continue
            
        if "," in line and "://" in line:
            parts = line.split(',', 1)
            if len(parts) == 2:
                channel_name, url = parts
                channel_id = f"{channel_name}|{url}"
                
                if channel_id not in seen_channels:
                    seen_channels.add(channel_id)
                    deduplicated.append(line)
    
    return deduplicated

def count_actual_channels(lines):
    """计算实际频道数量"""
    count = 0
    for line in lines:
        if line and "#genre#" not in line and line != '\n' and "," in line and "://" in line:
            count += 1
    return count

# 读取频道字典文件
print("📚 加载分类字典...")
yangshi_dictionary = read_txt_to_array('scripts/livesource/主频道/CCTV.txt')
weishi_dictionary = read_txt_to_array('scripts/livesource/主频道/卫视频道.txt')

beijing_dictionary = read_txt_to_array('scripts/livesource/地方台/北京频道.txt')
shanghai_dictionary = read_txt_to_array('scripts/livesource/地方台/上海频道.txt')
tianjin_dictionary = read_txt_to_array('scripts/livesource/地方台/天津频道.txt')
chongqing_dictionary = read_txt_to_array('scripts/livesource/地方台/重庆频道.txt')
guangdong_dictionary = read_txt_to_array('scripts/livesource/地方台/广东频道.txt')
jiangsu_dictionary = read_txt_to_array('scripts/livesource/地方台/江苏频道.txt')
zhejiang_dictionary = read_txt_to_array('scripts/livesource/地方台/浙江频道.txt')
shandong_dictionary = read_txt_to_array('scripts/livesource/地方台/山东频道.txt')
henan_dictionary = read_txt_to_array('scripts/livesource/地方台/河南频道.txt')
sichuan_dictionary = read_txt_to_array('scripts/livesource/地方台/四川频道.txt')
hebei_dictionary = read_txt_to_array('scripts/livesource/地方台/河北频道.txt')
hunan_dictionary = read_txt_to_array('scripts/livesource/地方台/湖南频道.txt')
hubei_dictionary = read_txt_to_array('scripts/livesource/地方台/湖北频道.txt')
anhui_dictionary = read_txt_to_array('scripts/livesource/地方台/安徽频道.txt')
fujian_dictionary = read_txt_to_array('scripts/livesource/地方台/福建频道.txt')
shanxi1_dictionary = read_txt_to_array('scripts/livesource/地方台/陕西频道.txt')
liaoning_dictionary = read_txt_to_array('scripts/livesource/地方台/辽宁频道.txt')
jiangxi_dictionary = read_txt_to_array('scripts/livesource/地方台/江西频道.txt')
heilongjiang_dictionary = read_txt_to_array('scripts/livesource/地方台/黑龙江频道.txt')
jilin_dictionary = read_txt_to_array('scripts/livesource/地方台/吉林频道.txt')
shanxi2_dictionary = read_txt_to_array('scripts/livesource/地方台/山西频道.txt')
guangxi_dictionary = read_txt_to_array('scripts/livesource/地方台/广西频道.txt')
yunnan_dictionary = read_txt_to_array('scripts/livesource/地方台/云南频道.txt')
guizhou_dictionary = read_txt_to_array('scripts/livesource/地方台/贵州频道.txt')
gansu_dictionary = read_txt_to_array('scripts/livesource/地方台/甘肃频道.txt')
neimenggu_dictionary = read_txt_to_array('scripts/livesource/地方台/内蒙频道.txt')
xinjiang_dictionary = read_txt_to_array('scripts/livesource/地方台/新疆频道.txt')
hainan_dictionary = read_txt_to_array('scripts/livesource/地方台/海南频道.txt')
ningxia_dictionary = read_txt_to_array('scripts/livesource/地方台/宁夏频道.txt')
qinghai_dictionary = read_txt_to_array('scripts/livesource/地方台/青海频道.txt')
xizang_dictionary = read_txt_to_array('scripts/livesource/地方台/西藏频道.txt')

news_dictionary = read_txt_to_array('scripts/livesource/主频道/新闻频道.txt')
shuzi_dictionary = read_txt_to_array('scripts/livesource/主频道/数字频道.txt')
dianying_dictionary = read_txt_to_array('scripts/livesource/主频道/电影频道.txt')
jieshuo_dictionary = read_txt_to_array('scripts/livesource/主频道/解说频道.txt')
zongyi_dictionary = read_txt_to_array('scripts/livesource/主频道/综艺频道.txt')
huya_dictionary = read_txt_to_array('scripts/livesource/主频道/虎牙直播.txt')
douyu_dictionary = read_txt_to_array('scripts/livesource/主频道/斗鱼直播.txt')
xianggang_dictionary = read_txt_to_array('scripts/livesource/主频道/香港频道.txt')
aomen_dictionary = read_txt_to_array('scripts/livesource/主频道/澳门频道.txt')
china_dictionary = read_txt_to_array('scripts/livesource/主频道/中国频道.txt')
guoji_dictionary = read_txt_to_array('scripts/livesource/主频道/国际频道.txt')
gangaotai_dictionary = read_txt_to_array('scripts/livesource/主频道/港澳台.txt')
dianshiju_dictionary = read_txt_to_array('scripts/livesource/主频道/电视剧.txt')
radio_dictionary = read_txt_to_array('scripts/livesource/主频道/收音机.txt')
donghuapian_dictionary = read_txt_to_array('scripts/livesource/主频道/动画片.txt')
jilupian_dictionary = read_txt_to_array('scripts/livesource/主频道/记录片.txt')
tiyu_dictionary = read_txt_to_array('scripts/livesource/主频道/体育频道.txt')
tiyusaishi_dictionary = read_txt_to_array('scripts/livesource/主频道/体育赛事.txt')
youxi_dictionary = read_txt_to_array('scripts/livesource/主频道/游戏频道.txt')
xiqu_dictionary = read_txt_to_array('scripts/livesource/主频道/戏曲频道.txt')
yinyue_dictionary = read_txt_to_array('scripts/livesource/主频道/音乐频道.txt')
chunwan_dictionary = read_txt_to_array('scripts/livesource/主频道/春晚频道.txt')
zhibozhongguo_dictionary = read_txt_to_array('scripts/livesource/主频道/直播中国.txt')

print(f"✅ 加载了 {len(yangshi_dictionary) + len(weishi_dictionary)} 个主频道字典")
print(f"✅ 加载了 {len(beijing_dictionary) + len(shanghai_dictionary) + len(tianjin_dictionary) + len(chongqing_dictionary)} 个地方台字典")

def get_random_url(file_path):
    """随机获取URL"""
    urls = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            url = line.strip().split(',')[-1]
            urls.append(url)    
    return random.choice(urls) if urls else None

def build_multiple_versions():
    """构建多个版本输出"""
    print("📋 开始构建多版本输出...")
    
    # 生成版本信息和推荐内容
    utc_time = datetime.now(timezone.utc)
    beijing_time = utc_time + timedelta(hours=8)
    formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")

    version = formatted_time + "," + (get_random_url('scripts/livesource/手工区/今日推台.txt') or "https://example.com")
    about = "xiaoranmuze," + (get_random_url('scripts/livesource/手工区/今日推台.txt') or "https://example.com")

    daily_mtv = "今日推荐," + (get_random_url('scripts/livesource/手工区/今日推荐.txt') or "https://example.com")
    daily_mtv1 = "🔥低调," + (get_random_url('scripts/livesource/手工区/今日推荐.txt') or "https://example.com")
    daily_mtv2 = "🔥使用," + (get_random_url('scripts/livesource/手工区/今日推荐.txt') or "https://example.com")
    daily_mtv3 = "🔥禁止," + (get_random_url('scripts/livesource/手工区/今日推荐.txt') or "https://example.com")
    daily_mtv4 = "🔥贩卖," + (get_random_url('scripts/livesource/手工区/今日推荐.txt') or "https://example.com")
    
    # 版本1: 完整版 - 包含所有分类 + 其它频道
    all_lines_full = [
        "🌐央视频道,#genre#"] + yangshi_lines + ['\n'] + \
        ["📡卫视频道,#genre#"] + weishi_lines + ['\n'] + \
        ["🏙️北京频道,#genre#"] + beijing_lines + ['\n'] + \
        ["🏙️上海频道,#genre#"] + shanghai_lines + ['\n'] + \
        ["🏙️天津频道,#genre#"] + tianjin_lines + ['\n'] + \
        ["🏙️重庆频道,#genre#"] + chongqing_lines + ['\n'] + \
        ["🏙️广东频道,#genre#"] + guangdong_lines + ['\n'] + \
        ["🏙️江苏频道,#genre#"] + jiangsu_lines + ['\n'] + \
        ["🏙️浙江频道,#genre#"] + zhejiang_lines + ['\n'] + \
        ["🏙️山东频道,#genre#"] + shandong_lines + ['\n'] + \
        ["🏙️河南频道,#genre#"] + henan_lines + ['\n'] + \
        ["🏙️四川频道,#genre#"] + sichuan_lines + ['\n'] + \
        ["🏙️河北频道,#genre#"] + hebei_lines + ['\n'] + \
        ["🏙️湖南频道,#genre#"] + hunan_lines + ['\n'] + \
        ["🏙️湖北频道,#genre#"] + hubei_lines + ['\n'] + \
        ["🏙️安徽频道,#genre#"] + anhui_lines + ['\n'] + \
        ["🏙️福建频道,#genre#"] + fujian_lines + ['\n'] + \
        ["🏙️陕西频道,#genre#"] + shanxi1_lines + ['\n'] + \
        ["🏙️辽宁频道,#genre#"] + liaoning_lines + ['\n'] + \
        ["🏙️江西频道,#genre#"] + jiangxi_lines + ['\n'] + \
        ["🏙️黑龙江频道,#genre#"] + heilongjiang_lines + ['\n'] + \
        ["🏙️吉林频道,#genre#"] + jilin_lines + ['\n'] + \
        ["🏙️山西频道,#genre#"] + shanxi2_lines + ['\n'] + \
        ["🏙️广西频道,#genre#"] + guangxi_lines + ['\n'] + \
        ["🏙️云南频道,#genre#"] + yunnan_lines + ['\n'] + \
        ["🏙️贵州频道,#genre#"] + guizhou_lines + ['\n'] + \
        ["🏙️甘肃频道,#genre#"] + gansu_lines + ['\n'] + \
        ["🏙️内蒙频道,#genre#"] + neimenggu_lines + ['\n'] + \
        ["🏙️新疆频道,#genre#"] + xinjiang_lines + ['\n'] + \
        ["🏙️海南频道,#genre#"] + hainan_lines + ['\n'] + \
        ["🏙️宁夏频道,#genre#"] + ningxia_lines + ['\n'] + \
        ["🏙️青海频道,#genre#"] + qinghai_lines + ['\n'] + \
        ["🏙️西藏频道,#genre#"] + xizang_lines + ['\n'] + \
        ["📰新闻频道,#genre#"] + news_lines + ['\n'] + \
        ["🔢数字频道,#genre#"] + shuzi_lines + ['\n'] + \
        ["🎬电影频道,#genre#"] + dianying_lines + ['\n'] + \
        ["🎙️解说频道,#genre#"] + jieshuo_lines + ['\n'] + \
        ["🎭综艺频道,#genre#"] + zongyi_lines + ['\n'] + \
        ["🐯虎牙直播,#genre#"] + huya_lines + ['\n'] + \
        ["🐬斗鱼直播,#genre#"] + douyu_lines + ['\n'] + \
        ["🇭🇰香港频道,#genre#"] + xianggang_lines + ['\n'] + \
        ["🇲🇴澳门频道,#genre#"] + aomen_lines + ['\n'] + \
        ["🇨🇳中国频道,#genre#"] + china_lines + ['\n'] + \
        ["🌍国际频道,#genre#"] + guoji_lines + ['\n'] + \
        ["🇨🇳港澳台,#genre#"] + gangaotai_lines + ['\n'] + \
        ["📺电视剧,#genre#"] + dianshiju_lines + ['\n'] + \
        ["📻收音机,#genre#"] + radio_lines + ['\n'] + \
        ["🐱动画片,#genre#"] + donghuapian_lines + ['\n'] + \
        ["🎞️记录片,#genre#"] + jilupian_lines + ['\n'] + \
        ["⚽体育频道,#genre#"] + tiyu_lines + ['\n'] + \
        ["🏆体育赛事,#genre#"] + tiyusaishi_lines + ['\n'] + \
        ["🎮游戏频道,#genre#"] + youxi_lines + ['\n'] + \
        ["👺戏曲频道,#genre#"] + xiqu_lines + ['\n'] + \
        ["🎵音乐频道,#genre#"] + yinyue_lines + ['\n'] + \
        ["🎉春晚频道,#genre#"] + chunwan_lines + ['\n'] + \
        ["📹直播中国,#genre#"] + zhibozhongguo_lines + ['\n'] + \
        ["🔍其它频道,#genre#"] + other_lines + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [daily_mtv] + [daily_mtv1] + [daily_mtv2] + [daily_mtv3] + [daily_mtv4] + read_txt_to_array('scripts/livesource/手工区/about.txt') + ['\n']
    
    # 版本2: 精简版 - 主要分类
    all_lines_lite = [
        "🌐央视频道,#genre#"] + yangshi_lines + ['\n'] + \
        ["📡卫视频道,#genre#"] + weishi_lines + ['\n'] + \
        ["🏠地方频道,#genre#"] + \
        beijing_lines + shanghai_lines + tianjin_lines + chongqing_lines + \
        guangdong_lines + jiangsu_lines + zhejiang_lines + shandong_lines + \
        henan_lines + sichuan_lines + hebei_lines + hunan_lines + hubei_lines + \
        anhui_lines + fujian_lines + shanxi1_lines + liaoning_lines + \
        jiangxi_lines + heilongjiang_lines + jilin_lines + shanxi2_lines + \
        guangxi_lines + yunnan_lines + guizhou_lines + gansu_lines + \
        neimenggu_lines + xinjiang_lines + hainan_lines + ningxia_lines + \
        qinghai_lines + xizang_lines + ['\n'] + \
        ["📰新闻频道,#genre#"] + news_lines + ['\n'] + \
        ["🎬电影频道,#genre#"] + dianying_lines + ['\n'] + \
        ["⚽体育频道,#genre#"] + tiyu_lines + ['\n'] + \
        ["🎭综艺频道,#genre#"] + zongyi_lines + ['\n'] + \
        ["🇭🇰港澳台,#genre#"] + xianggang_lines + aomen_lines + gangaotai_lines + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [daily_mtv] + read_txt_to_array('scripts/livesource/手工区/about.txt') + ['\n']
    
    # 版本3: 定制版 - 精选分类
    all_lines_custom = [
        "🌐央视频道,#genre#"] + yangshi_lines + ['\n'] + \
        ["📡卫视频道,#genre#"] + weishi_lines + ['\n'] + \
        ["🏠地方频道,#genre#"] + \
        beijing_lines + shanghai_lines + guangdong_lines + jiangsu_lines + \
        zhejiang_lines + shandong_lines + henan_lines + sichuan_lines + \
        hunan_lines + hubei_lines + ['\n'] + \
        ["📰新闻频道,#genre#"] + news_lines + ['\n'] + \
        ["🎬电影频道,#genre#"] + dianying_lines + ['\n'] + \
        ["⚽体育频道,#genre#"] + tiyu_lines + ['\n'] + \
        ["🎭综艺频道,#genre#"] + zongyi_lines + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [daily_mtv] + read_txt_to_array('scripts/livesource/手工区/about.txt') + ['\n']
    
    # 版本4: 其它版 - 未分类频道
    all_lines_other = [
        "🔍其它频道,#genre#"] + other_lines + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + read_txt_to_array('scripts/livesource/手工区/about.txt') + ['\n']
    
    return all_lines_full, all_lines_lite, all_lines_custom, all_lines_other

def save_all_versions(full, lite, custom, other):
    """保存所有版本"""
    versions = {
        'output/full.txt': full,
        'output/lite.txt': lite, 
        'output/custom.txt': custom,
        'output/other.txt': other
    }
    
    for filename, content in versions.items():
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                for line in content:
                    f.write(line + '\n')
            print(f"✅ 已保存: {filename}")
            
        except Exception as e:
            print(f"❌ 保存{filename}失败: {e}")

def print_final_statistics():
    """打印最终统计信息"""
    print("\n" + "="*70)
    print("📊 最终处理统计")
    print("="*70)
    
    # 分类统计
    categories = [
        ("央视频道", yangshi_lines),
        ("卫视频道", weishi_lines),
        ("北京频道", beijing_lines),
        ("上海频道", shanghai_lines),
        ("天津频道", tianjin_lines),
        ("重庆频道", chongqing_lines),
        ("广东频道", guangdong_lines),
        ("江苏频道", jiangsu_lines),
        ("浙江频道", zhejiang_lines),
        ("山东频道", shandong_lines),
        ("河南频道", henan_lines),
        ("四川频道", sichuan_lines),
        ("河北频道", hebei_lines),
        ("湖南频道", hunan_lines),
        ("湖北频道", hubei_lines),
        ("安徽频道", anhui_lines),
        ("福建频道", fujian_lines),
        ("陕西频道", shanxi1_lines),
        ("辽宁频道", liaoning_lines),
        ("江西频道", jiangxi_lines),
        ("黑龙江频道", heilongjiang_lines),
        ("吉林频道", jilin_lines),
        ("山西频道", shanxi2_lines),
        ("广西频道", guangxi_lines),
        ("云南频道", yunnan_lines),
        ("贵州频道", guizhou_lines),
        ("甘肃频道", gansu_lines),
        ("内蒙频道", neimenggu_lines),
        ("新疆频道", xinjiang_lines),
        ("海南频道", hainan_lines),
        ("宁夏频道", ningxia_lines),
        ("青海频道", qinghai_lines),
        ("西藏频道", xizang_lines),
        ("新闻频道", news_lines),
        ("数字频道", shuzi_lines),
        ("电影频道", dianying_lines),
        ("解说频道", jieshuo_lines),
        ("综艺频道", zongyi_lines),
        ("虎牙直播", huya_lines),
        ("斗鱼直播", douyu_lines),
        ("香港频道", xianggang_lines),
        ("澳门频道", aomen_lines),
        ("中国频道", china_lines),
        ("国际频道", guoji_lines),
        ("港澳台", gangaotai_lines),
        ("电视剧", dianshiju_lines),
        ("收音机", radio_lines),
        ("动画片", donghuapian_lines),
        ("记录片", jilupian_lines),
        ("体育频道", tiyu_lines),
        ("体育赛事", tiyusaishi_lines),
        ("游戏频道", youxi_lines),
        ("戏曲频道", xiqu_lines),
        ("音乐频道", yinyue_lines),
        ("春晚频道", chunwan_lines),
        ("直播中国", zhibozhongguo_lines),
        ("其它频道", other_lines)
    ]
    
    total_channels = 0
    print("📺 分类频道统计:")
    for name, lines in categories:
        count = count_actual_channels(lines)
        total_channels += count
        if count > 0:
            print(f"  {name}: {count}")
    
    print(f"\n📈 总计: {total_channels} 个频道")
    print("🎯 排序方式: 严格字典排序")
    print("🔄 去重规则: 分类内部去重，支持多分类")
    print("📋 输出版本: 完整版、精简版、定制版、其它版")
    print(f"🛡️  安全过滤: {len(combined_blacklist)} 条黑名单规则")

def main_corrected():
    """正确的主流程：保持多分类 + 纯净其他频道"""
    print("🚀 启动正确分类系统...")
    
    # 重置统计
    global classification_stats
    classification_stats = {}
    
    # 1. 加载扩展别名系统
    extended_aliases = load_extended_alias_system()
    corrections_name = load_corrections_name('scripts/livesource/corrections_name.txt')
    
    # 2. 处理URL源（使用正确的分类逻辑）
    urls = read_txt_to_array('scripts/livesource/urls-daily.txt')
    total_urls = len([url for url in urls if url.startswith("http")])
    processed_urls = 0
    
    for url in urls:
        if url.startswith("http"):
            processed_urls += 1
            print(f"📡 处理URL ({processed_urls}/{total_urls}): {url}")
            
            # 处理日期变量
            current_date_str = datetime.now().strftime("%m%d")
            yesterday_date_str = (datetime.now() - timedelta(days=1)).strftime("%m%d")
            url = url.replace("{MMdd}", current_date_str).replace("{MMdd-1}", yesterday_date_str)
            
            process_url_corrected(url, extended_aliases, corrections_name)
    
    # 3. 最终清理其他频道（确保纯净）
    global other_lines
    other_lines = correct_final_cleanup_other_channels()
    
    # 4. 应用字典排序
    apply_dictionary_sorting_to_all_categories()
    
    # 5. 构建多版本输出
    full_version, lite_version, custom_version, other_version = build_multiple_versions()
    
    # 6. 最终去重
    full_version = final_deduplicate_lines(full_version)
    lite_version = final_deduplicate_lines(lite_version) 
    custom_version = final_deduplicate_lines(custom_version)
    other_version = final_deduplicate_lines(other_version)
    
    # 7. 最终处理和保存
    save_all_versions(full_version, lite_version, custom_version, other_version)
    
    # 8. 生成统计报告
    print_final_statistics()
    
    # 计算执行时间
    timeend = datetime.now()
    elapsed_time = timeend - timestart
    total_seconds = elapsed_time.total_seconds()
    minutes = int(total_seconds // 60)
    seconds = int(total_seconds % 60)
    
    print(f"\n⏱️  执行时间: {minutes} 分 {seconds} 秒")
    print("🎉 处理完成！")

# 运行主程序
if __name__ == "__main__":
    main_corrected()