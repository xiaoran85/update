#!/bin/bash
echo "🚀 开始删除所有仓库的 Actions 日志..."

# 遍历所有仓库
gh repo list --json nameWithOwner --jq '.[] | .nameWithOwner' | while read -r REPO; do
    echo "🔍 处理仓库: $REPO"
    
    # 获取当前仓库所有 workflow runs ID
    RUN_IDS=$(gh api "repos/$REPO/actions/runs" --jq '.workflow_runs[].id')
    
    # 逐个删除
    for ID in $RUN_IDS; do
        echo "→ 删除日志: $ID"
        gh api -X DELETE "repos/$REPO/actions/runs/$ID"
    done
    
    echo "✅ 仓库 $REPO 日志清理完成"
done

echo "🎉 所有仓库日志删除完毕！"
