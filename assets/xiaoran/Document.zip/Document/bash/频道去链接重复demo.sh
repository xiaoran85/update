# 按分组去重，保留分组和唯一直播源名称
awk -F ',' '
  /,#genre#/ { 
    # 遇到新分组时，重置去重标记
    delete seen; 
    print $0;  # 保留分组行
    next 
  } 
  NF >= 1 { 
    name = $1; 
    if (!(name in seen)) {  # 只保留分组内首次出现的名称
      seen[name] = 1; 
      print name 
    } 
  }
' /storage/emulated/0/.subscribe-main/output/收藏频道.txt > /storage/emulated/0/.subscribe-main/output/demo.txt
