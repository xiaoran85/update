#!/data/data/com.termux/files/usr/bin/bash

# 配置参数
ACWING_USERNAME="xiaoran67"  
ACWING_PASSWORD="10066717Ac"     
REPO_NAME="source"              
LOCAL_CODE_PATH="/storage/emulated/0/.updates/update"  
BRANCH="main"  

# 检查本地目录
if [ ! -d "$LOCAL_CODE_PATH" ]; then
  echo "错误：本地目录不存在！"
  exit 1
fi
cd "$LOCAL_CODE_PATH" || exit 1

# 初始化 Git
echo "初始化本地仓库..."
git init

# 关键：创建动态标记文件（确保每次提交哈希不同）
echo "☘️ $(date +'%s%N')" > .force_sync_flag
git add .force_sync_flag  # 仅添加标记文件，避免大量文件变更（可根据需求调整）

# 提交（强制生成新提交）
git commit -m "FORCE_COVER: $(date +'%Y-%m-%d %H:%M:%S')"

git branch -M "$BRANCH"  

# 关联远程仓库
REMOTE_URL="https://$ACWING_USERNAME:$ACWING_PASSWORD@git.acwing.com/$ACWING_USERNAME/$REPO_NAME.git"
git remote add origin "$REMOTE_URL" 2>/dev/null || git remote set-url origin "$REMOTE_URL"

# 强制推送
echo "强制推送覆盖远程..."
git push -u origin "$BRANCH" --force

# 清理标记文件（可选，避免本地残留）
rm -f .force_sync_flag

# 检查结果
if [ $? -eq 0 ]; then
  echo "✅ 已强制覆盖远程仓库（新增标记文件确保变更）！"
else
  echo "❌ 推送失败！检查权限或网络。"
  exit 1
fi
