import os

# 目标目录路径（根据你的路径修改）
target_dir = "/storage/emulated/0/.subscribe-main/assets/blacklist1/blackhost"

# 存储所有行的集合（自动去重）
all_lines = set()

# 遍历目录下的所有文件
for filename in os.listdir(target_dir):
    # 只处理 txt 文件
    if filename.endswith(".txt"):
        file_path = os.path.join(target_dir, filename)
        try:
            # 读取文件内容（按行添加到集合）
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()  # 去除首尾空格和换行符
                    if line:  # 跳过空行
                        all_lines.add(line)
            print(f"已处理：{filename}")
        except Exception as e:
            print(f"处理 {filename} 出错：{e}")

# 保存合并去重后的结果（保存到当前目录的 merged_blackhost.txt）
output_path = os.path.join(target_dir, "merged_blackhost.txt")
with open(output_path, 'w', encoding='utf-8') as f:
    # 按行写入，每行一个内容
    for line in sorted(all_lines):  # sorted 可选，按字母排序
        f.write(line + '\n')

print(f"合并完成！结果保存到：{output_path}")
