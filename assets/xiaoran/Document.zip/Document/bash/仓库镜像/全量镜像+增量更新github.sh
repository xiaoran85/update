#!/data/data/com.termux/files/usr/bin/bash
# 全量+双向增量同步脚本
# 最后更新：2025-08-18

# 配置区
ACCESS_TOKEN="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"  # 替换为有效令牌
USERNAME="xiaoran67"
REPO_NAME="update"
PROJECT_DIR="/storage/emulated/0/.subscribe-main"
MAIN_BRANCH="main"  # 与远程默认分支一致

# 权限检测与引导
echo "🔒 检测 Termux 存储权限..."
if [ ! -d "$HOME/storage/shared" ]; then
    echo "⚠️ 未检测到存储权限，执行：termux-setup-storage 并授权"
    exit 1
else
    echo "✅ 已检测到存储权限"
fi

# 模式选择（3种模式）
echo "📋 请选择同步模式："
echo "【全量镜像模式】"
echo "1. 本地 → 远程（全量覆盖，远程完全复制本地）"
echo "2. 远程 → 本地（全量覆盖，本地完全复制远程）"
echo "【增量同步模式】"
echo "3. 双向增量更新（本地优先，自动处理分支分歧）"
read -p "请输入模式编号 [1-3]：" MODE

# 验证模式输入
if ! [[ "$MODE" =~ ^[1-3]$ ]]; then
    echo "❌ 无效输入！请输入1-3之间的数字"
    exit 1
fi

# 初始化同步流程
echo -e "\n💥 开始同步流程（模式：$MODE）"
echo "→ 目标仓库: $USERNAME/$REPO_NAME"
echo "→ 本地目录: $PROJECT_DIR"
echo "→ 分支: $MAIN_BRANCH"
echo "----------------------------------------"

# 步骤1：检测并创建本地目录
if [ ! -d "$PROJECT_DIR" ]; then
    echo "[1/7] 创建目录: $PROJECT_DIR"
    mkdir -p "$PROJECT_DIR" || { echo "❌ 创建目录失败"; exit 1; }
else
    echo "[1/7] 本地目录已存在"
fi

# 步骤2：进入项目目录
cd "$PROJECT_DIR" || { echo "❌ 进入目录失败"; exit 1; }
echo "[2/7] 工作目录: $(pwd)"

# 步骤3：初始化仓库（优化.git删除检测）
IS_NEW_REPO=0  # 标记是否为删除.git后的新仓库
if [ "$MODE" -eq 1 ] || [ "$MODE" -eq 2 ]; then
    # 全量模式：清除旧Git历史
    echo "[3/7] 全量模式：清除旧Git历史..."
    if [ -d ".git" ]; then
        rm -rf .git && echo "[3/7] ✅ 旧.git目录已彻底删除"
    else
        echo "[3/7] ℹ️ 未检测到旧.git目录，跳过删除"
    fi
    
    # 仅模式2删除本地文件
    if [ "$MODE" -eq 2 ]; then
        echo "[3/7] 模式2：删除本地文件以同步远程..."
        find . -maxdepth 1 -type f ! -name ".*" -delete > /dev/null 2>&1
        find . -maxdepth 1 -type d ! -name "." -exec rm -rf {} + > /dev/null 2>&1
        echo "[3/7] ✅ 本地非隐藏文件/目录已清除"
    fi
    
    # 重新初始化仓库
    echo "[3/7] 初始化新仓库..."
    git init --initial-branch="$MAIN_BRANCH" || { echo "❌ Git初始化失败"; exit 1; }
    echo "[3/7] ✅ 新仓库初始化完成"
else
    # 双向增量模式：检测.git是否被删除
    if [ ! -d .git ]; then
        echo "[3/7] 检测到.git目录已删除，初始化全新增量仓库..."
        git init --initial-branch="$MAIN_BRANCH" > /dev/null
        IS_NEW_REPO=1  # 标记为新仓库（本地优先）
        echo "[3/7] ✅ 全新增量仓库初始化完成"
    else
        echo "[3/7] ℹ️ 检测到现有增量仓库，保留历史"
    fi
    # 关联远程分支（兼容新仓库）
    git fetch origin "$MAIN_BRANCH" > /dev/null 2>&1
    if ! git branch --show-current | grep -q "$MAIN_BRANCH"; then
        git checkout -b "$MAIN_BRANCH" --track origin/"$MAIN_BRANCH" > /dev/null 2>&1
        echo "[3/7] ✅ 已创建并关联分支: $MAIN_BRANCH"
    else
        git branch --set-upstream-to=origin/"$MAIN_BRANCH" "$MAIN_BRANCH" > /dev/null 2>&1
        echo "[3/7] ✅ 分支已关联远程: $MAIN_BRANCH"
    fi
fi

# 步骤4：配置远程仓库
REMOTE_URL="https://$ACCESS_TOKEN@github.com/$USERNAME/$REPO_NAME.git"
echo "[4/7] 配置远程仓库: $REMOTE_URL"
if ! git remote | grep -q "origin"; then
    git remote add origin "$REMOTE_URL" || { echo "❌ 添加远程仓库失败"; exit 1; }
    echo "[4/7] ✅ 已添加远程仓库: origin"
else
    git remote set-url origin "$REMOTE_URL" || { echo "❌ 更新远程地址失败"; exit 1; }
    echo "[4/7] ✅ 已更新远程仓库地址"
fi

# 步骤5：拉取操作（核心优化：自动配置拉取策略）
if [ "$MODE" -eq 2 ] || [ "$MODE" -eq 3 ]; then
    echo "[5/7] 拉取远程内容..."
    if [ "$MODE" -eq 2 ]; then
        # 全量拉取（模式2）
        if git pull origin "$MAIN_BRANCH" --force; then
            echo "[5/7] ✅ 本地已完全同步远程内容"
        else
            echo "❌ 全量拉取失败！检查远程仓库或分支"
            exit 1
        fi
    else
        # 模式3拉取：自动配置Git策略，确保本地优先
        echo "[5/7] 配置本地优先拉取策略..."
        git config pull.rebase true         # 启用rebase拉取
        git config rebase.autoStash true    # 自动暂存本地变更
        echo "[5/7] ✅ 拉取策略配置完成（本地优先）"
        
        if [ $IS_NEW_REPO -eq 1 ]; then
            # 刚删除.git：先提交本地文件，拉取时强制本地优先
            echo "[5/7] 新仓库模式：本地文件优先处理..."
            git add -f . > /dev/null 2>&1
            git commit -m "✨ $(date +'%Y-%m-%d %H:%M:%S')" --quiet 2>/dev/null || true
            # 拉取远程并自动保留本地内容
            if git pull origin "$MAIN_BRANCH" --strategy-option=ours; then
                echo "[5/7] ✅ 远程内容拉取完成，冲突自动保留本地"
            else
                echo "❌ 拉取冲突，强制用本地内容覆盖..."
                git pull origin "$MAIN_BRANCH" --force || { echo "❌ 强制拉取失败"; exit 1; }
            fi
        else
            # 正常增量拉取：冲突时本地优先
            if git pull --rebase -X ours origin "$MAIN_BRANCH"; then
                echo "[5/7] ✅ 远程增量拉取完成，冲突自动保留本地"
            else
                echo "❌ 拉取冲突，自动用本地内容覆盖..."
                git rebase --abort > /dev/null 2>&1
                git pull origin "$MAIN_BRANCH" --strategy-option=ours || { echo "❌ 覆盖失败"; exit 1; }
            fi
        fi
    fi
fi

# 步骤6：提交准备（模式3强制本地文件）
if [ "$MODE" -eq 1 ] || [ "$MODE" -eq 3 ]; then
    echo "[6/7] 处理本地文件..."
    git add -f . > /dev/null 2>&1  # 强制添加所有本地文件（优先本地）
    FILE_COUNT=$(git status --short | wc -l)
    echo "[6/7] ✅ 已添加 $FILE_COUNT 个本地变更文件（本地优先）"
    git commit -m "🔄 $(date +'%Y-%m-%d %H:%M:%S')" --quiet 2>/dev/null || true
fi

# 步骤7：推送操作（模式3确保本地内容上传）
if [ "$MODE" -eq 1 ] || [ "$MODE" -eq 3 ]; then
    echo "[7/7] 推送本地内容..."
    # 检查远程仓库是否存在
    if ! git ls-remote --exit-code origin > /dev/null 2>&1; then
        echo "⚠️ 远程仓库不存在，尝试创建..."
        curl -X POST \
            -H "Authorization: token $ACCESS_TOKEN" \
            -H "Accept: application/vnd.github.v3+json" \
            "https://api.github.com/user/repos" \
            -d "{\"name\":\"$REPO_NAME\",\"private\":false}" &>/dev/null
        sleep 3
        echo "[7/7] ℹ️ 远程仓库创建尝试完成"
    fi
    # 推送策略：全量强制，增量本地优先
    if [ "$MODE" -eq 1 ]; then
        PUSH_CMD="git push --force origin $MAIN_BRANCH"
    else
        PUSH_CMD="git push --force-with-lease origin $MAIN_BRANCH"  # 确保本地内容优先推送
    fi
    if $PUSH_CMD; then
        echo "[7/7] ✅ 本地内容推送成功（本地优先）"
    else
        echo "❌ 推送失败！可能原因：权限不足或远程有保护分支"
        exit 1
    fi
fi

# 结果验证
if [ $? -eq 0 ]; then
    echo -e "\n💥 同步成功！"
    case $MODE in
        1) echo "→ 结果：远程已完全复制本地（全量覆盖）" ;;
        2) echo "→ 结果：本地已完全复制远程（全量覆盖）" ;;
        3) echo "→ 结果：双向增量同步完成（自动处理分支分歧，本地内容优先）" ;;
    esac
    echo "→ 仓库地址: https://github.com/$USERNAME/$REPO_NAME"
else
    echo -e "\n❌ 同步失败！请根据上方错误信息排查"
fi
