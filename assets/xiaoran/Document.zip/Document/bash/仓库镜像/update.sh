#!/data/data/com.termux/files/usr/bin/bash
# ===== 终极强制推送脚本 =====
# 特点：无视一切规则强制推送整个目录
# 最后更新：2025-07-21

# ====================== 配置区 ======================
ACCESS_TOKEN="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"  # 👈 必须更新！
USERNAME="xiaoran67"
REPO_NAME="update"
PROJECT_DIR="/storage/emulated/0/.updates/update"
MAIN_BRANCH="main"

# ====================== 初始化 ======================
echo "💥 开始终极强制推送！"
echo "→ 目标仓库: $USERNAME/$REPO_NAME"
echo "→ 本地目录: $PROJECT_DIR"
echo "→ 强制覆盖: 是"
echo "----------------------------------------"

# ===== 1. 进入项目目录 =====
cd "$PROJECT_DIR" || { echo "❌ 目录不存在"; exit 1; }
echo "[1/5] 进入目录: $(pwd)"

# ===== 2. 销毁旧Git记录 =====
[ -d .git ] && rm -rf .git
find . -name ".git" -exec rm -rf {} + 2>/dev/null
echo "[2/5] 清理完成: 移除所有Git历史"

# ===== 3. 初始化新仓库 =====
git init --initial-branch="$MAIN_BRANCH" > /dev/null || {
    git init
    git checkout -b "$MAIN_BRANCH"
}
echo "[3/5] 仓库初始化: 分支 $MAIN_BRANCH"

# ===== 4. 强制添加所有文件 =====
git add -f . > /dev/null 2>&1
FILE_COUNT=$(git status --short | wc -l)
echo "[4/5] 添加文件: $FILE_COUNT 个文件(强制包含所有)"

# ===== 5. 强制推送 =====
echo "[5/5] 正在强制推送..."
git commit -m "☘️ $(date +'%Y-%m-%d %H:%M:%S')" --quiet
git remote add origin "https://$ACCESS_TOKEN@github.com/$USERNAME/$REPO_NAME.git"

# 终极强制推送（多次尝试）
for i in {1..3}; do
    git push --force --set-upstream origin "$MAIN_BRANCH" &> push.log
    if [ $? -eq 0 ]; then
        break
    elif grep -q "Repository not found" push.log; then
        echo "⚠️ 仓库不存在，尝试创建..."
        curl -X POST \
            -H "Authorization: token $ACCESS_TOKEN" \
            -H "Accept: application/vnd.github.v3+json" \
            "https://api.github.com/user/repos" \
            -d "{\"name\":\"$REPO_NAME\",\"private\":false}" &>/dev/null
        sleep 2
    fi
done

# ===== 结果验证 =====
if [ $? -eq 0 ]; then
    echo -e "\n💥 强制推送成功！仓库已被完全覆盖"
    echo "→ 仓库地址: https://github.com/$USERNAME/$REPO_NAME"
    echo "→ 分支: $MAIN_BRANCH"
    echo "→ 文件数: $FILE_COUNT"
else
    echo -e "\n❌ 推送失败！最终解决方案:"
    echo "1. 手动创建空仓库: https://github.com/new?name=$REPO_NAME"
    echo "2. 确认ACCESS_TOKEN有效且有repo权限"
    echo "3. 再次运行本脚本"
    echo "错误日志:"
    cat push.log
fi

# 清理日志
rm -f push.log