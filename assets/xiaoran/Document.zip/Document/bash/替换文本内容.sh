#!/data/data/com.termux/files/usr/bin/bash

# ==============================================
# 配置模块（可根据需求自定义修改）
# ==============================================
# 目标根目录（递归查找此目录下的所有.sh文件）
TARGET_ROOT_DIR="/storage/emulated/0/.updates/.subscribe-main/assets/xiaoran/Document"
# 要替换的旧字符串
OLD_STRING="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"
# 替换后的新字符串
NEW_STRING="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"
# 目标文件后缀（如需修改为其他类型文件，只需改这里）
FILE_SUFFIX="*.sh"
# ==============================================

# 检查目标目录是否存在
if [ ! -d "$TARGET_ROOT_DIR" ]; then
    echo "❌ 错误：目标目录不存在 - $TARGET_ROOT_DIR"
    exit 1
fi

# 统计符合条件的文件数量
file_count=$(find "$TARGET_ROOT_DIR" -type f -name "$FILE_SUFFIX" | wc -l | tr -d ' ')
if [ "$file_count" -eq 0 ]; then
    echo "⚠️ 提示：未找到任何 $FILE_SUFFIX 文件"
    exit 0
fi

echo "✅ 找到 $file_count 个 $FILE_SUFFIX 文件，开始替换..."
echo "----------------------------------------"

# 递归替换核心逻辑
find "$TARGET_ROOT_DIR" -type f -name "$FILE_SUFFIX" | while read -r file; do
    echo "处理文件：$file"
    # 执行替换
    sed -i "s/$OLD_STRING/$NEW_STRING/g" "$file"
    # 输出结果
    if [ $? -eq 0 ]; then
        echo "  ✅ 替换成功"
    else
        echo "  ❌ 替换失败（可能无权限或文件异常）"
    fi
done

echo "----------------------------------------"
echo "✨ 所有文件处理完成"
