cd /storage/emulated/0/.subscribe-main/library && \
find . -type f \( -name "*.json" -o -name "*.txt" \) | sed "s|^\./|https://raw.githubusercontent.com/xiaoran67/update/main/library/|" > /storage/emulated/0/.Abner/library_json_txt_links.txt && \
cd - && \
echo "✅ library目录下json和txt文件直链已保存到 /storage/emulated/0/.Abner/library_json_txt_links.txt"
