import os
import subprocess
import tempfile

def main():
    # 仓库与输出配置
    REPO_URL = "https://github.com/xiaoran67/update.git"
    BRANCH = "main"
    TARGET_DIR = "output"  # 仓库内要爬取的目录
    OUTPUT_FILE = "/storage/emulated/0/.Abner/link.txt"

    try:
        # 1. 创建临时目录（自动清理）
        with tempfile.TemporaryDirectory() as tmp_dir:
            print("🚀 开始克隆仓库...")
            # 2. 浅克隆仓库（仅拉取最新版本，速度快）
            clone_cmd = [
                "git", "clone", "--depth", "1", 
                "--branch", BRANCH, 
                REPO_URL, tmp_dir
            ]
            subprocess.run(clone_cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            print("✅ 仓库克隆成功")

            # 3. 进入仓库内的目标目录，生成直链
            target_path = os.path.join(tmp_dir, TARGET_DIR)
            os.chdir(target_path)

            print("🔍 开始生成文件直链...")
            # 查找所有文件 + 替换为 raw 直链格式
            find_cmd = ["find", ".", "-type", "f"]
            sed_cmd = [
                "sed", 
                "s|^\\./|https://raw.githubusercontent.com/xiaoran67/update/main/output/|"
            ]
            with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
                find_proc = subprocess.Popen(find_cmd, stdout=subprocess.PIPE)
                sed_proc = subprocess.Popen(sed_cmd, stdin=find_proc.stdout, stdout=f)
                find_proc.stdout.close()  # 确保子进程协同退出
                sed_proc.wait()

            print(f"✅ 直链已保存到 {OUTPUT_FILE}")

    except subprocess.CalledProcessError as e:
        print(f"❌ 命令执行失败: {e.stderr.decode('utf-8')}")
    except Exception as e:
        print(f"❌ 发生错误: {str(e)}")
    finally:
        print("✨ 临时文件已自动清理，操作完成")

if __name__ == "__main__":
    main()
