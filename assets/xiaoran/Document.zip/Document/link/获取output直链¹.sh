cd /storage/emulated/0/.subscribe-main/output && \
find . -type f \( -name "*.txt" -o -name "*.m3u" \) | sed "s|^\./|https://raw.githubusercontent.com/xiaoran67/update/main/output/|" > /storage/emulated/0/.Abner/output_txt_m3u_links.txt && \
cd - && \
echo "✅ output目录下txt和m3u文件直链已保存到 /storage/emulated/0/.Abner/output_txt_m3u_links.txt"
