tmp_dir=$(mktemp -d) && \
git clone --depth 1 https://github.com/xiaoran67/update.git "$tmp_dir" && \
cd "$tmp_dir/library" && \
find . -type f -name "*.json" | sed "s|^\./|https://raw.githubusercontent.com/xiaoran67/update/main/library/|" > /storage/emulated/0/.Abner/library_json_links.txt && \
cd - && \
rm -rf "$tmp_dir" && \
echo "✅ library目录下json文件直链已保存到 /storage/emulated/0/.Abner/library_json_links.txt"
