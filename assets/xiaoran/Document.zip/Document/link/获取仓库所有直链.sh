tmp_dir=$(mktemp -d) && \
git clone --depth 1 https://github.com/xiaoran67/update.git "$tmp_dir" && \
cd "$tmp_dir" && \
mkdir -p /storage/emulated/0/.Abner/links_by_dir && \
# 遍历非.git目录，用完整路径哈希避免同名冲突
find . -type d ! -path "./.git" ! -path "." | while read -r dir; do
  # 对目录完整路径生成唯一哈希名（避免同名目录冲突）
  dir_hash=$(echo -n "$dir" | md5sum | cut -c1-8)
  dir_name=$(basename "$dir")
  # 文件名格式：哈希_目录名_links.txt
  output_file="/storage/emulated/0/.Abner/links_by_dir/${dir_hash}_${dir_name}_links.txt"
  find "$dir" -type f | sed "s|^\./|https://raw.githubusercontent.com/xiaoran67/update/main/|" > "$output_file"
done && \
cd - && \
rm -rf "$tmp_dir" && \
echo "✅ 按目录分文件保存完成（含同名目录处理），路径：/storage/emulated/0/.Abner/links_by_dir"
